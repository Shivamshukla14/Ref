from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.http import require_GET

from .models import Service, ServiceCategory, ServiceSubCategory, ServiceSubSubCategory

@require_GET
def services_list(request):
    items = list(Service.objects.filter(is_active=True).values("id", "name", "code"))
    return JsonResponse({"results": items})

@require_GET
def categories_by_service(request):
    service_id = request.GET.get("service_id")
    if not service_id:
        return HttpResponseBadRequest("service_id is required")
    items = list(ServiceCategory.objects.filter(service_id=service_id, is_active=True).values("id", "name", "code"))
    return JsonResponse({"results": items})

@require_GET
def subcategories_by_category(request):
    category_id = request.GET.get("category_id")
    if not category_id:
        return HttpResponseBadRequest("category_id is required")
    items = list(ServiceSubCategory.objects.filter(category_id=category_id, is_active=True).values("id", "name", "code"))
    return JsonResponse({"results": items})

@require_GET
def subsub_by_subcategory(request):
    subcategory_id = request.GET.get("subcategory_id")
    if not subcategory_id:
        return HttpResponseBadRequest("subcategory_id is required")
    items = list(ServiceSubSubCategory.objects.filter(sub_category_id=subcategory_id, is_active=True).values("id", "name", "code"))
    return JsonResponse({"results": items})