from django.db import models

class TicketMaster(models.Model):
    issue_id = models.AutoField(primary_key=True)
    ticket_id = models.CharField(max_length=30, unique=True)
    app_id = models.ForeignKey('applications.Application', on_delete=models.PROTECT)
    reported_by = models.CharField(max_length=10)  # HRMS emp_code reference
    # Service taxonomy
    service = models.ForeignKey('catalog.Service', on_delete=models.PROTECT)
    category = models.ForeignKey('catalog.ServiceCategory', on_delete=models.PROTECT)
    sub_category = models.ForeignKey('catalog.ServiceSubCategory', on_delete=models.PROTECT, null=True, blank=True)
    sub_sub_category = models.ForeignKey('catalog.ServiceSubSubCategory', on_delete=models.PROTECT, null=True, blank=True)
    # Requested For (emp_code if Other; Self will mirror reported_by)
    requested_for_code = models.CharField(max_length=10, null=True, blank=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    priority = models.CharField(max_length=15)
    status = models.CharField(max_length=50, default='Unassigned')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    due_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    has_attachments = models.BooleanField(default=False)

    class Meta:
        db_table = 'ticket_master'

    def __str__(self):
        return f"{self.ticket_id} - {self.title}"

class TicketAttachment(models.Model):
    attachment_id = models.AutoField(primary_key=True)
    issue = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    file_name = models.TextField()
    s3_path = models.TextField(blank=True)
    uploaded_by = models.CharField(max_length=10)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_attachments'

    def __str__(self):
        return f"{self.issue_id} - {self.file_name}"


class TicketAssignment(models.Model):
    assignment_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    assigned_by = models.CharField(max_length=10)  # HRMS emp_code reference
    assigned_to = models.CharField(max_length=10)  # HRMS emp_code reference
    assigned_by_role = models.CharField(max_length=60)  # Role name of the assigner
    assigned_at = models.DateTimeField(auto_now_add=True)


    class Meta:
        db_table = 'ticket_assignment'

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.assigned_to}"
    
class TicketComment(models.Model):
    comment_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    commented_by = models.CharField(max_length=10)  # HRMS emp_code reference
    comment_text = models.TextField()
    commented_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_comments'

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.commented_by}"