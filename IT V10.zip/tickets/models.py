from django.db import models

class TicketMaster(models.Model):
    issue_id = models.AutoField(primary_key=True)
    ticket_id = models.CharField(max_length=30, unique=True)
    app_id = models.ForeignKey('applications.Application', on_delete=models.PROTECT, null=True, blank=True)
    reported_by = models.CharField(max_length=10)  # HRMS emp_code reference
    # Service taxonomy
    service = models.ForeignKey('catalog.Service', on_delete=models.PROTECT)
    category = models.ForeignKey('catalog.ServiceCategory', on_delete=models.PROTECT)
    sub_category = models.ForeignKey('catalog.ServiceSubCategory', on_delete=models.PROTECT, null=True, blank=True)
    sub_sub_category = models.ForeignKey('catalog.ServiceSubSubCategory', on_delete=models.PROTECT, null=True, blank=True)
    # Requested For (emp_code if Other; Self will mirror reported_by)
    requested_for_code = models.CharField(max_length=10, null=True, blank=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    priority = models.CharField(max_length=15)
    status = models.CharField(max_length=50, default='Unassigned')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    due_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    has_attachments = models.BooleanField(default=False)

    class Meta:
        db_table = 'ticket_master'

    def __str__(self):
        return f"{self.ticket_id} - {self.title}"

class TicketAttachment(models.Model):
    attachment_id = models.AutoField(primary_key=True)
    issue = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    file_name = models.TextField()
    s3_path = models.TextField(blank=True)
    uploaded_by = models.CharField(max_length=10)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_attachments'

    def __str__(self):
        return f"{self.issue_id} - {self.file_name}"


class TicketAssignment(models.Model):
    assignment_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    assigned_by = models.CharField(max_length=10)  # HRMS emp_code reference
    assigned_to = models.CharField(max_length=10)  # HRMS emp_code reference
    assigned_by_role = models.CharField(max_length=60)  # Role name of the assigner
    reassigned = models.BooleanField(default=False)
    remark = models.TextField(blank=True)
    assigned_at = models.DateTimeField(auto_now_add=True)


    class Meta:
        db_table = 'ticket_assignment'
        indexes = [
            models.Index(fields=['issue_id', 'assigned_at']),
        ]

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.assigned_to}"
    
class TicketComment(models.Model):
    comment_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    commented_by = models.CharField(max_length=10)  # HRMS emp_code reference
    comment_text = models.TextField()
    is_resolution = models.BooleanField(default=False)
    commented_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_comments'
        indexes = [
            models.Index(fields=['issue_id', 'commented_at']),
        ]

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.commented_by}"
    

class TicketEscalation(models.Model):
    escalation_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    escalated_to = models.CharField(max_length=10)  # HRMS emp_code reference
    escalated_to_role = models.CharField(max_length=60)  # Role name of the escalatee
    escalated_by = models.CharField(max_length=10)  # HRMS emp_code reference
    escalated_at = models.DateTimeField(auto_now_add=True)
    reason = models.TextField()
    resolved = models.BooleanField(default=False)

    class Meta:
        db_table = 'ticket_escalations'
        indexes = [
            models.Index(fields=['issue_id', 'escalated_at']),
        ]

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.escalated_to_role}"
    
class TicketAssetDetails(models.Model):
    asset_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    asset_tag = models.CharField(max_length=50)
    asset_type = models.CharField(max_length=100)
    serial_number = models.CharField(max_length=100)
    created_on = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_asset_details'

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.asset_tag}"
    
class TicketExtraFields(models.Model):
    extra_field_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    field_key = models.CharField(max_length=100)
    field_value = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_extra_fields'

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.field_key}"
    
class TicketResolution(models.Model):
    resolution_id = models.AutoField(primary_key=True)
    issue_id = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    resolved_by = models.CharField(max_length=10)  # HRMS emp_code reference
    resolution_summary = models.TextField()
    resolved_at = models.DateTimeField(auto_now_add=True)
    within_sla = models.BooleanField(default=True)
    remarks = models.TextField(blank=True)

    class Meta:
        db_table = 'ticket_resolution'

    def __str__(self):
        return f"{self.issue_id.ticket_id} - {self.resolved_by}"