# Issue Tracker – Initial Auth & Integrations Scaffolding

This initial scaffold adds:
- Azure SSO login button (UI) and a test login bypass via email
- `Role` and `RoleMapping` models (app-level RBAC)
- HRMS lookup service (read-only reference to `test_app_logging.hrms`)
- S3 integration module (commented with full code, ready to configure)
- Email API integration stub (prints payload for now)

This is a minimal baseline intended to be expanded into the full application.

## Quick Start

1. Create a Python 3.11.3 virtual environment and install requirements:

```bash
python -m venv .venv
. .venv/Scripts/activate
pip install -r requirements.txt
```

2. Set environment variables (dev):

```bash
set DJANGO_SECRET_KEY=dev-secret
set DJANGO_DEBUG=True
set DJANGO_ALLOWED_HOSTS=*
set DATABASE_URL=postgres://user:pass@localhost:5432/yourdb
set AZURE_CLIENT_ID=your-client-id
set AZURE_TENANT_ID=your-tenant-id
set AZURE_REDIRECT_URI=http://localhost:8000/auth/azure/callback/
set AWS_S3_BUCKET=your-bucket-name
set AWS_REGION=your-region
set AWS_ACCESS_KEY_ID=your-access-key
set AWS_SECRET_ACCESS_KEY=your-secret
```

3. Run migrations and start server:

```bash
python manage.py migrate
python manage.py runserver
```

4. Open the login page at `/auth/login/` to use Azure SSO button or the bypass email form.

Notes:
- S3 and Email integrations are stubbed; they won’t send or upload yet.
- HRMS reads assume a cross-schema table `test_app_logging.hrms` accessible to the DB user.
