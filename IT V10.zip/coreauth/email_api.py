"""
Email API Integration (Stub) - prints payload for now.
Expected to send HTML emails via external API.
"""

from typing import List, Optional
import json


def send_email_stub(to: List[str], subject: str, html_body: str, cc: Optional[List[str]] = None) -> None:
    payload = {
        "to": to,
        "subject": subject,
        "html_body": html_body,
        "cc": cc or [],
    }
    print("[EMAIL STUB] Would send email with payload:")
    print(json.dumps(payload, indent=2))
