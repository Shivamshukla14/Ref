"""
AWS S3 Integration (Commented for now) – ready to enable later.

This module provides functions to upload and generate presigned URLs.
Currently, all operational calls are commented out per requirement.
"""

from typing import Optional
# import boto3
# from botocore.exceptions import ClientError
from django.conf import settings


def s3_ticket_folder(ticket_code: str, year: int, month: int, day: int) -> str:
    return f"{year:04d}/{month:02d}/{day:02d}/{ticket_code}/"


def upload_file_stub(file_bytes: bytes, key: str, content_type: str) -> Optional[str]:
    """
    Stub: intended to upload file_bytes to S3 under given key.
    Returns the S3 key if successful. Currently returns key and prints.
    """
    bucket = settings.AWS_S3_BUCKET
    region = settings.AWS_REGION
    print(f"[S3 STUB] Would upload to bucket={bucket} region={region} key={key} content_type={content_type}")
    # s3 = boto3.client(
    #     's3',
    #     region_name=region,
    #     aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    #     aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    # )
    # try:
    #     s3.put_object(Bucket=bucket, Key=key, Body=file_bytes, ContentType=content_type)
    #     return key
    # except ClientError as e:
    #     print(f"S3 upload error: {e}")
    #     return None
    return key


def generate_presigned_url_stub(key: str, expires_in: int = 3600) -> Optional[str]:
    """
    Stub: intended to generate a presigned URL for the given key.
    Currently prints and returns a fake URL for UI testing.
    """
    bucket = settings.AWS_S3_BUCKET
    region = settings.AWS_REGION
    fake_url = f"https://s3.{region}.amazonaws.com/{bucket}/{key}?fakeSigned=1&expires={expires_in}"
    print(f"[S3 STUB] Would generate presigned URL for key={key} -> {fake_url}")
    # s3 = boto3.client('s3', region_name=region,
    #                   aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    #                   aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)
    # try:
    #     url = s3.generate_presigned_url('get_object', Params={'Bucket': bucket, 'Key': key}, ExpiresIn=expires_in)
    #     return url
    # except ClientError as e:
    #     print(f"S3 presign error: {e}")
    #     return None
    return fake_url
