from django.db import models

class Service(models.Model):
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=20, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "service"

    def __str__(self):
        return self.name

class ServiceCategory(models.Model):
    service = models.ForeignKey(Service, on_delete=models.PROTECT)
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "service_category"
        unique_together = ("service", "code")

    def __str__(self):
        return f"{self.service.name} / {self.name}"

class ServiceSubCategory(models.Model):
    category = models.ForeignKey(ServiceCategory, on_delete=models.PROTECT)
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "service_sub_category"
        unique_together = ("category", "code")

    def __str__(self):
        return f"{self.category} / {self.name}"

class ServiceSubSubCategory(models.Model):
    sub_category = models.ForeignKey(ServiceSubCategory, on_delete=models.PROTECT)
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "service_sub_sub_category"
        unique_together = ("sub_category", "code")

    def __str__(self):
        return f"{self.sub_category} / {self.name}"
    

class PriorityMapping(models.Model):
    PRIORITY_CHOICES = [
        ('P1', 'Cr itical'),
        ('P2', 'High'),
        ('P3', 'Medium'),
        ('P4', 'Low'),
    ]

    service_category = models.ForeignKey(ServiceCategory, on_delete=models.PROTECT)
    service_sub_category = models.ForeignKey(ServiceSubCategory, on_delete=models.PROTECT, null=True, blank=True)
    service_sub_sub_category = models.ForeignKey(ServiceSubSubCategory, on_delete=models.PROTECT, null=True, blank=True)

    impact = models.PositiveSmallIntegerField() # 1 to 4
    urgency = models.PositiveSmallIntegerField() # 1 to 4

    priority_code = models.CharField(max_length=2, choices=PRIORITY_CHOICES)

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "priority_mapping"
        unique_together = (
            "service_category",
            "service_sub_category",
            "service_sub_sub_category"
            )


    def __str__(self):
        return f"{self.priority_code} ({self.impact}x{self.urgency})"
    

class SLASetting(models.Model):
    sla_id = models.AutoField(primary_key=True)
    priority_code = models.CharField(max_length=2)
    resolution_time_hours = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "sla_setting"
        unique_together = ("priority_code",)

    def __str__(self):
        return f"SLA {self.priority_code} - {self.resolution_time_hours} hrs"
    

class ServiceDeleteHistory(models.Model):
    delete_id = models.AutoField(primary_key=True)
    service_name = models.CharField(max_length=100)
    service_code = models.CharField(max_length=20)
    deleted_at = models.DateTimeField(auto_now_add=True)
    deleted_by = models.CharField(max_length=10)  # HRMS emp_code reference

    class Meta:
        db_table = "service_delete_history"

    def __str__(self):
        return f"Deleted Service: {self.service_name} at {self.deleted_at}"
    
class CategoryDeleteHistory(models.Model):
    delete_id = models.AutoField(primary_key=True)
    category_name = models.CharField(max_length=100)
    category_code = models.CharField(max_length=30)
    deleted_at = models.DateTimeField(auto_now_add=True)
    deleted_by = models.CharField(max_length=10)  # HRMS emp_code reference

    class Meta:
        db_table = "category_delete_history"

    def __str__(self):
        return f"Deleted Category: {self.category_name} at {self.deleted_at}"
    
class SubCategoryDeleteHistory(models.Model):
    delete_id = models.AutoField(primary_key=True)
    sub_category_name = models.CharField(max_length=100)
    sub_category_code = models.CharField(max_length=30)
    deleted_at = models.DateTimeField(auto_now_add=True)
    deleted_by = models.CharField(max_length=10)  # HRMS emp_code reference

    class Meta:
        db_table = "sub_category_delete_history"

    def __str__(self):
        return f"Deleted Sub-Category: {self.sub_category_name} at {self.deleted_at}"
    
class SubSubCategoryDeleteHistory(models.Model):
    delete_id = models.AutoField(primary_key=True)
    sub_sub_category_name = models.CharField(max_length=100)
    sub_sub_category_code = models.CharField(max_length=30)
    deleted_at = models.DateTimeField(auto_now_add=True)
    deleted_by = models.CharField(max_length=10)  # HRMS emp_code reference

    class Meta:
        db_table = "sub_sub_category_delete_history"

    def __str__(self):
        return f"Deleted Sub-Sub-Category: {self.sub_sub_category_name} at {self.deleted_at}"
    
class PriorityMappingUpdateHistory(models.Model):
    update_id = models.AutoField(primary_key=True)
    service_category = models.CharField(max_length=100)
    service_sub_category = models.CharField(max_length=100, null=True, blank=True)
    service_sub_sub_category = models.CharField(max_length=100, null=True, blank=True)
    impact = models.PositiveSmallIntegerField()
    urgency = models.PositiveSmallIntegerField()
    old_priority_code = models.CharField(max_length=2)
    updated_at = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=10)  # HRMS emp_code reference

    class Meta:
        db_table = "priority_mapping_update_history"

    def __str__(self):
        return f"Priority Update: {self.service_category} from {self.old_priority_code} at {self.updated_at}"
    

