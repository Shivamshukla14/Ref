# NIDO IAM Role — Django Skeleton

This is a Django project skeleton implementing Azure AD SSO, unmanaged models mapped to existing Postgres tables, a dashboard, and email flows with optional Celery.

## Requirements
- Python 3.10+
- Postgres database with existing tables
- Redis (optional for Celery)

## Setup (Windows cmd)

```cmd
:: create venv
python -m venv .venv

:: activate
.\.venv\Scripts\activate

:: install
pip install -r requirements.txt

:: copy env
copy .env.example .env

:: edit .env with your values
notepad .env

:: run migrations for auth/session/tables (models are unmanaged)
cd nido_iamRole
python manage.py migrate

:: runserver
python manage.py runserver
```

Login at `/auth/azure/login/`.

## Celery (optional)

```cmd
:: in one terminal
redis-server

:: in another terminal (from repo root)
.\.venv\Scripts\activate
cd nido_iamRole
celery -A nido_iamRole worker -l info
```

## Notes
- Models for HRMS and master systems are `managed = False` and expect existing tables.
- Presence lookups use fast `exists()` queries.
- Azure AD via `django-auth-adfs`; ensure app registration and redirect URL match `.env`.
- Email uses SMTP settings from `.env`. Without Celery, sending occurs inline.