from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from django.views.generic import RedirectView
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    # Place the specific login redirect BEFORE the include so it wins
    path('auth/azure/login/', RedirectView.as_view(url='/auth/azure/oauth2/login/', permanent=False), name='azure-login'),
    path('auth/azure/', include('django_auth_adfs.urls')),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('', RedirectView.as_view(url='/login/', permanent=False), name='root-redirect'),
    path('', include('core.urls')),
]
