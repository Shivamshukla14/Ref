import os
from pathlib import Path
import environ
import dj_database_url

BASE_DIR = Path(__file__).resolve().parent.parent

env = environ.Env(
    DEBUG=(bool, False)
)

# Load .env if present (try multiple locations)
_env_paths = [
    BASE_DIR / '.env',
    BASE_DIR.parent / '.env',
    BASE_DIR.parent.parent / '.env',
]
for _p in _env_paths:
    if os.path.exists(_p):
        environ.Env.read_env(_p)
        break

# DEBUG = env('DEBUG')
DEBUG = True  # Temporarily force DEBUG True for local dev
SECRET_KEY = env('SECRET_KEY', default='unsafe-secret-key')
ALLOWED_HOSTS = [h.strip() for h in env('ALLOWED_HOSTS', default='').split(',') if h.strip()] or ['*']

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django_auth_adfs',
    'django_celery_results',
    'core',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'nido_iamRole.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'core' / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'nido_iamRole.wsgi.application'
ASGI_APPLICATION = 'nido_iamRole.asgi.application'

# Database
DATABASE_URL = env('DATABASE_URL', default=None)
if DATABASE_URL:
    DATABASES = {
        'default': dj_database_url.parse(DATABASE_URL, conn_max_age=600, ssl_require=False)
    }
else:
    # Fallback to SQLite for dev if no DATABASE_URL
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [BASE_DIR / 'core' / 'static'] if (BASE_DIR / 'core' / 'static').exists() else []

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Email
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
DEFAULT_FROM_EMAIL = env('DEFAULT_FROM_EMAIL', default='no-reply@example.com')
EMAIL_HOST = env('EMAIL_HOST', default='localhost')
EMAIL_PORT = int(env('EMAIL_PORT', default=25))
EMAIL_HOST_USER = env('EMAIL_HOST_USER', default='')
EMAIL_HOST_PASSWORD = env('EMAIL_HOST_PASSWORD', default='')
EMAIL_USE_TLS = env.bool('EMAIL_USE_TLS', default=False)

# Auth backends with Azure AD via django-auth-adfs
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'django_auth_adfs.backend.AdfsAuthCodeBackend',
]

LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/dashboard/'
LOGOUT_REDIRECT_URL = '/'

AZURE_TENANT_ID = env('AZURE_TENANT_ID', default='')
AZURE_CLIENT_ID = env('AZURE_CLIENT_ID', default='local-dev-client-id')
AZURE_CLIENT_SECRET = env('AZURE_CLIENT_SECRET', default='')
AZURE_REDIRECT_URI = env('AZURE_REDIRECT_URI', default='')

# django-auth-adfs settings
from django.urls import reverse_lazy
AUTH_ADFS = {
    'TENANT_ID': AZURE_TENANT_ID or 'common',
    'CLIENT_ID': AZURE_CLIENT_ID,
    'CLIENT_SECRET': AZURE_CLIENT_SECRET,
    'RELYING_PARTY_ID': AZURE_CLIENT_ID,
    'AUDIENCE': env('AUTH_ADFS_AUDIENCE', default=AZURE_CLIENT_ID or 'local-dev-client-id'),
    'REDIR_URI': AZURE_REDIRECT_URI or '',
    'CLAIM_MAPPING': {
        'first_name': 'given_name',
        'last_name': 'family_name',
        'email': 'email',
        'upn': 'upn',
        'name': 'name',
    },
    'USERNAME_CLAIM': 'upn',
    'GROUPS_CLAIM': 'groups',
    'MIRROR_GROUPS': False,
    'CREATE_NEW_USERS': True,
    'LOGIN_EXEMPT_URLS': [r'^healthz$'],
}

# Celery
CELERY_BROKER_URL = env('CELERY_BROKER_URL', default='redis://localhost:6379/0')
CELERY_RESULT_BACKEND = env('CELERY_RESULT_BACKEND', default='redis://localhost:6379/1')
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'

# django-celery-results
CELERY_CACHE_BACKEND = 'default'
