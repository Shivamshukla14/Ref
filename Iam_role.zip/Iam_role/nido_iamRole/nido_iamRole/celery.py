import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nido_iamRole.settings')

app = Celery('nido_iamRole')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()
