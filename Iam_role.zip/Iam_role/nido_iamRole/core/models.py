from django.db import models


class Hrms(models.Model):
    emp_code = models.CharField(max_length=50, primary_key=True)
    login = models.CharField(max_length=150, blank=True, null=True)
    birth_date = models.DateField(blank=True, null=True)
    first_name = models.CharField(max_length=150, blank=True, null=True)
    last_name = models.CharField(max_length=150, blank=True, null=True)
    entity_name = models.CharField(max_length=150, blank=True, null=True)
    internal_designation = models.CharField(max_length=150, blank=True, null=True)
    sub_job_code = models.CharField(max_length=150, blank=True, null=True)
    external_designation = models.CharField(max_length=150, blank=True, null=True)
    employee_status = models.CharField(max_length=50, blank=True, null=True)
    role = models.CharField(max_length=150, blank=True, null=True)
    dependent_role = models.CharField(max_length=150, blank=True, null=True)
    ra_e_code = models.CharField(max_length=50, blank=True, null=True)
    reporting_manager = models.CharField(max_length=150, blank=True, null=True)
    last_work_date = models.DateField(blank=True, null=True)
    date_of_join = models.DateField(blank=True, null=True)
    business_email = models.EmailField(max_length=254, blank=True, null=True)
    ra_email = models.EmailField(max_length=254, blank=True, null=True)
    office_mobile = models.CharField(max_length=50, blank=True, null=True)
    personal_mobile = models.CharField(max_length=50, blank=True, null=True)
    created_on = models.DateTimeField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    num = models.IntegerField(blank=True, null=True)
    nido_entity = models.BooleanField(default=False)

    class Meta:
        managed = False
        db_table = 'hrms'

    def __str__(self):
        return f"{self.emp_code} - {self.first_name or ''} {self.last_name or ''}".strip()

    def get_ra_email(self):
        return (self.ra_email or '').strip()

    def is_in_table(self, table_model):
        email = (self.business_email or '').strip()
        if not email:
            return False
        # Assumes target model has a user_email or email field
        if hasattr(table_model, 'objects'):
            q = models.Q()
            if 'user_email' in [f.name for f in table_model._meta.get_fields() if hasattr(f, 'name')]:
                q |= models.Q(user_email__iexact=email)
            if 'email' in [f.name for f in table_model._meta.get_fields() if hasattr(f, 'name')]:
                q |= models.Q(email__iexact=email)
            return table_model.objects.filter(q).exists()
        return False


class RpulseUserMaster(models.Model):
    user_email = models.EmailField(max_length=254, blank=True, null=True)
    user_name = models.CharField(max_length=150, blank=True, null=True)
    user_create_date = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = 'rpulse_user_master'

    def __str__(self):
        return self.user_email or ''


class DreUserMaster(models.Model):
    user_email = models.EmailField(max_length=254, blank=True, null=True)
    user_name = models.CharField(max_length=150, blank=True, null=True)
    user_create_date = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = 'dre_user_master'

    def __str__(self):
        return self.user_email or ''


class IngeniousUsersMaster(models.Model):
    user_email = models.EmailField(max_length=254, blank=True, null=True)
    user_name = models.CharField(max_length=150, blank=True, null=True)
    user_create_date = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = 'ingenious_users_master'

    def __str__(self):
        return self.user_email or ''


class ExponentiaUserMaster(models.Model):
    user_email = models.EmailField(max_length=254, blank=True, null=True)
    user_name = models.CharField(max_length=150, blank=True, null=True)
    user_create_date = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = 'exponentia_user_master'

    def __str__(self):
        return self.user_email or ''


class NeoUserMaster(models.Model):
    user_email = models.EmailField(max_length=254, blank=True, null=True)
    user_name = models.CharField(max_length=150, blank=True, null=True)
    user_create_date = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = 'neo_user_master'

    def __str__(self):
        return self.user_email or ''
