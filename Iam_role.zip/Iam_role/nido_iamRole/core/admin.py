from django.contrib import admin
from .models import Hrms


@admin.register(Hrms)
class HrmsAdmin(admin.ModelAdmin):
    list_display = ('emp_code', 'first_name', 'last_name', 'business_email', 'entity_name', 'employee_status')
    search_fields = ('emp_code', 'first_name', 'last_name', 'business_email')
