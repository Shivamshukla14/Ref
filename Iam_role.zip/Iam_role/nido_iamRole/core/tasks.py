from celery import shared_task
from django.core.mail import EmailMultiAlternatives


@shared_task
def send_email_task(subject: str, to: list[str], html_body: str, text_body: str | None = None):
    msg = EmailMultiAlternatives(subject, text_body or ' ', to=to)
    msg.attach_alternative(html_body, 'text/html')
    msg.send()
