from django.urls import path

from . import views

urlpatterns = [
    path('login/', views.dev_login, name='login'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('healthz', views.healthz, name='healthz'),
    path('api/check-presence/', views.check_presence_api, name='check-presence'),
    path('api/hrms/<str:emp_code>/presence/', views.hrms_presence_partial, name='hrms-presence-partial'),
    path('action/initiate-certification/', views.initiate_certification, name='initiate-certification'),
    path('action/revoke-access/', views.revoke_access, name='revoke-access'),
    path('action/recertify/<str:emp_code>/', views.recertify, name='recertify'),
    path('ajax/user-access-table/', views.ajax_user_access_table, name='ajax-user-access-table'),
    path('ajax/ra-user-access-table/', views.ajax_ra_user_access_table, name='ajax-ra-user-access-table'),
    path('ajax/employee-details-table/', views.ajax_employee_details_table, name='ajax-employee-details-table'),
]
