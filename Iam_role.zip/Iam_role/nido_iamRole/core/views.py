from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET, require_POST
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.core.paginator import Paginator
from django.db.models import Q

# AJAX endpoint for RA User Access table pagination
@login_required
@require_GET
def ajax_ra_user_access_table(request):
    all_rows = get_hrms_list()
    email = (request.user.email or '').lower()
    my_rows = [r for r in all_rows if (r.get('ra_email') or '').lower() == email]
    ra_access_rows = []
    for emp in my_rows:
        presence = presence_for_email(emp.get('business_email'))
        ra_access_rows.append({
            'emp_code': emp['emp_code'],
            'first_name': emp['first_name'],
            'last_name': emp['last_name'],
            'business_email': emp['business_email'],
            'presence': presence,
            'module': emp.get('module', ''),
            'user_role': emp.get('user_role', ''),
            'menu_name': emp.get('menu_name', ''),
            'user_role_name': emp.get('user_role_name', ''),
            'roles': emp.get('roles', ''),
            'status_tc': emp.get('status_tc', ''),
        })
    ra_access_page_param = request.GET.get('ra_access_page') or 1
    ra_access_paginator = Paginator(ra_access_rows, 25)
    ra_access_page_obj = ra_access_paginator.get_page(ra_access_page_param)
    context = {
        'ra_access_page_obj': ra_access_page_obj,
    }
    return render(request, 'partials/ra_user_access_table.html', context)
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET, require_POST
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.core.paginator import Paginator
from django.db.models import Q

# AJAX endpoint for Employee Details table pagination
@login_required
@require_GET
def ajax_employee_details_table(request):
    all_rows = get_hrms_list()
    # Use the same filtering as dashboard view for Employee Details
    page_size = 25
    page_param = request.GET.get('page') or 1
    paginator = Paginator(all_rows, page_size)
    page_obj = paginator.get_page(page_param)
    context = {
        'page_obj': page_obj,
    }
    return render(request, 'partials/employee_details_table.html', context)
from django.core.mail import EmailMultiAlternatives
from django.contrib.auth import get_user_model, login as auth_login
from django.conf import settings

# AJAX endpoint for User Access table pagination
@login_required
@require_GET
def ajax_user_access_table(request):
    all_rows = get_hrms_list()
    nido_rows_full = [
        {**r, 'presence': presence_for_email(r.get('business_email'))}
        for r in all_rows if 'nido' in (r.get('entity_name') or '').lower()
    ]
    page_size = 25
    access_page_param = request.GET.get('access_page') or 1
    paginator_access = Paginator(nido_rows_full, page_size)
    page_obj_access = paginator_access.get_page(access_page_param)
    context = {
        'nido_rows': page_obj_access.object_list,
        'page_obj_access': page_obj_access,
    }
    return render(request, 'partials/user_access_table.html', context)
from django.utils import timezone

# from .models import (
#     Hrms,
#     RpulseUserMaster,
#     DreUserMaster,
#     IngeniousUsersMaster,
#     ExponentiaUserMaster,
#     NeoUserMaster,
# )
from .dummy_data import get_hrms_list, presence_for_email

try:
    from .tasks import send_email_task
    HAS_CELERY = True
except Exception:
    HAS_CELERY = False


def healthz(request):
    return JsonResponse({'ok': True})

def dev_login(request):
    """Temporary dev login page that bypasses SSO. Use only for development."""
    if request.method == 'POST':
        email = (request.POST.get('email') or '').strip()
        first_name = (request.POST.get('first_name') or '').strip()
        next_url = request.POST.get('next') or '/dashboard/'
        if not email:
            return render(request, 'login.html', {'error': 'Email is required', 'next': next_url, 'hide_header': True})
        User = get_user_model()
        username = email
        user, _created = User.objects.get_or_create(username=username, defaults={'email': email})
        # Update fields on every login for convenience during dev
        user.email = email
        if first_name:
            user.first_name = first_name
        try:
            user.set_unusable_password()
        except Exception:
            pass
        user.save()
        auth_login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        return redirect(next_url)
    # GET
    # Allow debug auto-login via query params for testing
    if settings.DEBUG and request.GET.get('auto') == '1' and request.GET.get('email'):
        email = (request.GET.get('email') or '').strip()
        first_name = (request.GET.get('first_name') or '').strip()
        next_url = request.GET.get('next') or '/dashboard/'
        User = get_user_model()
        user, _ = User.objects.get_or_create(username=email, defaults={'email': email})
        user.email = email
        if first_name:
            user.first_name = first_name
        try:
            user.set_unusable_password()
        except Exception:
            pass
        user.save()
        auth_login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        return redirect(next_url)
    next_url = request.GET.get('next') or '/dashboard/'
    return render(request, 'login.html', {'next': next_url, 'hide_header': True})

def _presence_for_email(email: str) -> dict:
    # return presence via dummy data
    return presence_for_email(email)


@login_required
def dashboard(request):
    try:
        user = request.user
        email = (user.email or '').lower()
        first_name = user.first_name or (user.get_full_name().split(' ')[0] if user.get_full_name() else '')

        context = {
            'first_name': first_name,
            'user_email': email,
            'is_dinesh': email == 'dinesh.singh@test.com',
        }

        if context['is_dinesh']:
            # Global view using dummy data
            all_rows = get_hrms_list()
            # Pagination using Django Paginator directly
            page_size = 25
            page_param = request.GET.get('page') or 1
            paginator = Paginator(all_rows, page_size)
            page_obj = paginator.get_page(page_param)
            # Attach presence for NIDO-like rows and paginate for User Access
            nido_rows_full = [
                {**r, 'presence': _presence_for_email(r.get('business_email'))}
                for r in all_rows if 'nido' in (r.get('entity_name') or '').lower()
            ]
            access_page_param = request.GET.get('access_page') or 1
            paginator_access = Paginator(nido_rows_full, page_size)
            page_obj_access = paginator_access.get_page(access_page_param)

            context.update({
                'page_obj': page_obj,
                'presence_map': {},
                'nido_rows': page_obj_access.object_list,
                'page_obj_access': page_obj_access,
                'nido_tab': True,
            })
            return render(request, 'dashboard.html', context)

        # RA-specific view using dummy data
        all_rows = get_hrms_list()
        my_rows = [r for r in all_rows if (r.get('ra_email') or '').lower() == email]
        active_rows = [r for r in my_rows if r.get('employee_status') == 'A']
        inactive_nido_rows = [
            r for r in my_rows
            if r.get('employee_status') == 'I' and ((r.get('entity_name') or '').lower() == 'nido' or r.get('nido_entity'))
        ]
        presence_preview = {r['emp_code']: _presence_for_email(r.get('business_email')) for r in my_rows[:200]}

        # RA User Access: show all employees under this RA, with app access columns (like admin)
        # Use presence_for_email for each employee
        ra_access_rows = []
        for emp in my_rows:
            presence = _presence_for_email(emp.get('business_email'))
            ra_access_rows.append({
                'emp_code': emp['emp_code'],
                'first_name': emp['first_name'],
                'last_name': emp['last_name'],
                'business_email': emp['business_email'],
                'presence': presence,
                'module': emp.get('module', ''),
                'user_role': emp.get('user_role', ''),
                'menu_name': emp.get('menu_name', ''),
                'user_role_name': emp.get('user_role_name', ''),
                'roles': emp.get('roles', ''),
                'status_tc': emp.get('status_tc', ''),
            })
        ra_access_page_param = request.GET.get('ra_access_page') or 1
        ra_access_paginator = Paginator(ra_access_rows, 25)
        ra_access_page_obj = ra_access_paginator.get_page(ra_access_page_param)
        context.update({
            'my_rows': my_rows,
            'active_rows': active_rows,
            'inactive_nido_rows': inactive_nido_rows,
            'presence_preview': presence_preview,
            'ra_access_page_obj': ra_access_page_obj,
        })
        return render(request, 'dashboard.html', context)
    except Exception as e:
        if settings.DEBUG:
            return render(request, 'dashboard.html', {'error': str(e), 'first_name': request.user.first_name})
        raise


@login_required
def check_presence_api(request):
    email = request.GET.get('email', '').strip()
    if not email:
        return JsonResponse({'error': 'email required'}, status=400)
    return JsonResponse({'email': email, 'presence': _presence_for_email(email)})


@login_required
def hrms_presence_partial(request, emp_code: str):
    # find row in dummy data
    rows = get_hrms_list()
    row = next((r for r in rows if r.get('emp_code') == emp_code), None)
    if not row:
        return JsonResponse({'error': 'not found'}, status=404)
    presence = _presence_for_email(row.get('business_email'))
    return JsonResponse({'emp_code': emp_code, 'presence': presence, 'user_email': row.get('business_email') or ''})


def _send_email(subject: str, to: list[str], html_body: str, text_body: str | None = None):
    if HAS_CELERY:
        send_email_task.delay(subject, to, html_body, text_body)
    else:
        msg = EmailMultiAlternatives(subject, text_body or ' ', to=to)
        msg.attach_alternative(html_body, 'text/html')
        msg.send()


@login_required
def initiate_certification(request):
    # Only privileged user
    if (request.user.email or '').lower() != 'dinesh.singh@test.com':
        return HttpResponseForbidden('Not allowed')
    # Gather distinct RA emails for NIDO from dummy data
    all_rows = get_hrms_list()
    ra_emails = sorted({r.get('ra_email') for r in all_rows if ('nido' in (r.get('entity_name') or '').lower()) or r.get('nido_entity')})
    for ra in ra_emails:
        if not ra:
            continue
        rows = [type('Obj', (), r) for r in all_rows if (r.get('ra_email') or '').lower() == (ra or '').lower()]
        context = {'rows': rows, 'ra_email': ra, 'initiated_by': request.user.email, 'ts': timezone.now()}
        html = render(request, 'emails/initiative_certification.html', context).content.decode('utf-8')
        _send_email('Initiate Certification', [ra], html)
    return redirect('dashboard')


@login_required
@require_POST
def revoke_access(request):
    emp_code = request.POST.get('hrms_id')
    rpulse = request.POST.get('rpulse') == 'true'
    dre = request.POST.get('dre') == 'true'
    ingenious = request.POST.get('ingenious') == 'true'
    exponentia = request.POST.get('exponentia') == 'true'
    neo = request.POST.get('neo') == 'true'
    ra_email = (request.POST.get('ra_email') or '').strip()

    if not emp_code:
        return HttpResponseBadRequest('Missing hrms_id')
    # locate hrms row in dummy
    hrms_row = next((r for r in get_hrms_list() if r.get('emp_code') == emp_code), None)
    if not hrms_row:
        return JsonResponse({'error': 'not found'}, status=404)

    # Validate ownership
    if (request.user.email or '').lower() != (hrms_row.get('ra_email') or '').lower():
        return HttpResponseForbidden('You are not authorized for this record')

    to = ['test@test.com']
    html = render(request, 'emails/revoke_access_notification.html', {
        'hrms': type('Obj', (), hrms_row),
        'states': {
            'rpulse': rpulse,
            'dre': dre,
            'ingenious': ingenious,
            'exponentia': exponentia,
            'neo': neo,
        },
        'submitted_by': request.user.email,
        'ts': timezone.now(),
    }).content.decode('utf-8')
    _send_email(f'Revoke Access Request for {hrms_row.get("first_name") or ""} {hrms_row.get("last_name") or ""} ({hrms_row.get("emp_code")})', to, html)
    return JsonResponse({'ok': True})


@login_required
def recertify(request, emp_code: str):
    # Dummy find
    hrms_row = next((r for r in get_hrms_list() if r.get('emp_code') == emp_code), None)
    if not hrms_row:
        return JsonResponse({'error': 'not found'}, status=404)
    if (request.user.email or '').lower() != (hrms_row.get('ra_email') or '').lower():
        return HttpResponseForbidden('Not allowed')
    to = ['xyz@xyz.com']
    html = render(request, 'emails/recertification_request.html', {
        'hrms': type('Obj', (), hrms_row),
        'submitted_by': request.user.email,
        'ts': timezone.now(),
    }).content.decode('utf-8')
    _send_email(f'Recertification Request for {hrms_row.get("first_name") or ""} {hrms_row.get("last_name") or ""} ({hrms_row.get("emp_code")})', to, html)
    return redirect('dashboard')
