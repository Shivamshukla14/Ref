from django.urls import path
from . import views

urlpatterns = [
    path("services/", views.services_list, name="services_list"),
    path("categories/", views.categories_by_service, name="categories_by_service"),
    path("subcategories/", views.subcategories_by_category, name="subcategories_by_category"),
    path("subsubs/", views.subsub_by_subcategory, name="subsub_by_subcategory"),
]