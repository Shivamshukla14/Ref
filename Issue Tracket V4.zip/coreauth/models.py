from django.db import models

class Role(models.Model):
    # resolvex.role
    name = models.CharField(max_length=60, unique=True)  # User, SM1, SM2, Engineer, Admin
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "resolvex_role"

    def __str__(self):
        return self.name

class RoleMapping(models.Model):
    # resolvex.role_mapping
    role = models.ForeignKey(Role, on_delete=models.PROTECT)
    emp_code = models.CharField(max_length=10, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "resolvex_role_mapping"

    def __str__(self):
        return f"{self.emp_code} -> {self.role.name}"

class HrmsEmployee(models.Model):
    emp_code = models.CharField(max_length=10, primary_key=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    business_email = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = '"test_app_logging"."hrms"'

    def __str__(self):
        return f"{self.emp_code} - {self.first_name} {self.last_name}"
