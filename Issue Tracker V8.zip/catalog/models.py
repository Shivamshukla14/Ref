from django.db import models

class Service(models.Model):
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=20, unique=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "service"

    def __str__(self):
        return self.name

class ServiceCategory(models.Model):
    service = models.ForeignKey(Service, on_delete=models.PROTECT)
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "service_category"
        unique_together = ("service", "code")

    def __str__(self):
        return f"{self.service.name} / {self.name}"

class ServiceSubCategory(models.Model):
    category = models.ForeignKey(ServiceCategory, on_delete=models.PROTECT)
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "service_sub_category"
        unique_together = ("category", "code")

    def __str__(self):
        return f"{self.category} / {self.name}"

class ServiceSubSubCategory(models.Model):
    sub_category = models.ForeignKey(ServiceSubCategory, on_delete=models.PROTECT)
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "service_sub_sub_category"
        unique_together = ("sub_category", "code")

    def __str__(self):
        return f"{self.sub_category} / {self.name}"
    

class PriorityMapping(models.Model):
    PRIORITY_CHOICES = [
        ('P1', 'Cr itical'),
        ('P2', 'High'),
        ('P3', 'Medium'),
        ('P4', 'Low'),
    ]

    service_category = models.ForeignKey(ServiceCategory, on_delete=models.PROTECT)
    service_sub_category = models.ForeignKey(ServiceSubCategory, on_delete=models.PROTECT, null=True, blank=True)
    service_sub_sub_category = models.ForeignKey(ServiceSubSubCategory, on_delete=models.PROTECT, null=True, blank=True)

    impact = models.PositiveSmallIntegerField() # 1 to 4
    urgency = models.PositiveSmallIntegerField() # 1 to 4

    priority_code = models.CharField(max_length=2, choices=PRIORITY_CHOICES)

    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "priority_mapping"
        unique_together = (
            "service_category",
            "service_sub_category",
            "service_sub_sub_category"
            )


    def __str__(self):
        return f"{self.priority_code} ({self.impact}x{self.urgency})"
    

class SLASetting(models.Model):
    sla_id = models.AutoField(primary_key=True)
    priority_code = models.CharField(max_length=2)
    resolution_time_hours = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "sla_setting"
        unique_together = ("priority_code",)

    def __str__(self):
        return f"SLA {self.priority_code} - {self.resolution_time_hours} hrs"