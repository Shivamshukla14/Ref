from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from django.conf import settings
from django.http import HttpResponseBadRequest
from urllib.parse import urlencode

from .hrms_service import get_employee_by_business_email
from .models import Role, RoleMapping


@require_http_methods(["GET"])
def login_view(request):
    return render(request, "login.html")


@require_http_methods(["GET"])
def azure_start(request):
    """
    Start Azure SSO by redirecting to Microsoft login URL.
    Note: For now this constructs an OAuth2 authorize URL (no token exchange implemented).
    """
    client_id = settings.AZURE_CLIENT_ID
    tenant = settings.AZURE_TENANT_ID
    redirect_uri = settings.AZURE_REDIRECT_URI
    if not client_id or not tenant:
        return HttpResponseBadRequest("Azure SSO not configured")

    auth_base = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
    query = urlencode({
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "response_mode": "query",
        "scope": "openid profile email",
        "state": "dev-state",
    })
    return redirect(f"{auth_base}?{query}")


@require_http_methods(["GET"])
def azure_callback(request):
    """
    Azure OAuth2 callback stub: prints the 'code' and directs to a landing page.
    In production, exchange code for tokens, validate, and map to HRMS user.
    """
    code = request.GET.get("code")
    if not code:
        return HttpResponseBadRequest("Missing code")

    # Stub: pretend we decoded and validated identity
    request.session["sso_code_received"] = True
    # Do not send email on login per requirement
    return redirect("/auth/user/dashboard/")


@require_http_methods(["POST"])
def bypass_login(request):
    """
    Bypass login using HRMS business_email. This sets session with emp_code and role.
    """
    email = request.POST.get("email", "").strip().lower()
    if not email:
        return HttpResponseBadRequest("Email is required")

    hrms = get_employee_by_business_email(email)
    if not hrms:
        return HttpResponseBadRequest("HRMS record not found for provided email")

    emp_code = hrms["emp_code"]

    # Map application role via RoleMapping; if missing, default to 'User' role (created if needed)
    mapping = RoleMapping.objects.filter(emp_code=emp_code).select_related("role").first()
    if not mapping:
        desired_role_name = (hrms.get("role") or "User").strip()
        if desired_role_name not in ("User", "SM1", "SM2"):
            desired_role_name = "User"
        desired_role, _ = Role.objects.get_or_create(name=desired_role_name)
        mapping = RoleMapping.objects.create(emp_code=emp_code, role=desired_role)

    # Set session values (simulate SSO-authenticated principal)
    request.session["emp_code"] = emp_code
    request.session["business_email"] = hrms["business_email"]
    request.session["role"] = mapping.role.name
    request.session["first_name"] = hrms.get("first_name")
    request.session["last_name"] = hrms.get("last_name")

    # Do not send email on login per requirement

    # Redirect based on role
    if mapping.role.name == "User":
        return redirect("/auth/user/dashboard/")
    if mapping.role.name in ("SM1", "SM2"):
        return redirect("/auth/sm/dashboard/")
    if mapping.role.name == "Engineer":
        return redirect("/auth/eng/my-task/")
    # Unknown role -> send to login
    return redirect("/auth/login/")


@require_http_methods(["GET"])
def user_dashboard(request):
    """Simple User dashboard per wireframe (static KPIs for now)."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/sm/dashboard/") if role in ("SM1", "SM2") else redirect("/auth/login/")
    context = {
        "first_name": request.session.get("first_name", ""),
        "kpi_total": 0,
        "kpi_open": 0,
        "kpi_in_progress": 0,
        "kpi_resolved": 0,
        "tickets": [],  # will be populated when ticket models exist
    }
    return render(request, "user_dashboard.html", context)


@require_http_methods(["GET"])
def user_new_ticket(request):
    """Render the New Ticket form (UI only for now)."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/login/")
    return render(request, "user_new_ticket.html")


@require_http_methods(["GET"])
def user_my_tickets(request):
    """Render the My Tickets page per wireframe (static sample data)."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/login/")

    # Sample tickets until persistence exists
    tickets = [
        {
            "ticket_code": "N-EXP-001",
            "title": "Login Failure on iOS",
            "application": "Exponentia",
            "priority": "High",
            "status": "In Progress",
            "created_at": "11-11-2024",
            "updated_at": "11-11-2024",
            "description": "Cannot log in to the app after latest update. Error code 503.",
            "attachments": ["screenshot_error.png"],
            "resolution_time": "4 Hours (Set by Engineer)",
            "history": [
                "Cannot log in to the app after latest update. Error code 503.",
            ],
            "comments": [],
        }
    ]

    context = {"tickets": tickets}
    return render(request, "user_my_tickets.html", context)


@require_http_methods(["GET"])
def root_redirect(request):
    """Redirect root to dashboard if logged in, else to login."""
    if request.session.get("emp_code"):
        role = request.session.get("role")
        if role == "User":
            return redirect("/auth/user/dashboard/")
        if role in ("SM1", "SM2"):
            return redirect("/auth/sm/dashboard/")
        if role == "Engineer":
            return redirect("/auth/eng/my-task/")
    return redirect("/auth/login/")
@require_http_methods(["GET"])
def sm_dashboard(request):
    """Service Manager dashboard (SM1/SM2) per wireframe with static data."""
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")

    context = {
        "kpi_tickets": 98,
        "kpi_open": 56,
        "kpi_in_progress": 36,
        "kpi_resolved_on_time": 42,
        "kpi_breached_sla": 12,
        "unassigned": [
            {"ticket_code": "N-EXP-1001", "title": "Login Issue", "reporter": "David", "created": "11-12-2025"},
        ],
        "charts": {
            "priority": {"high": 10, "medium": 18, "low": 12}
        }
    }
    return render(request, "sm_dashboard.html", context)


@require_http_methods(["GET"])
def sm_tickets(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    context = {"title": "All Tickets"}
    return render(request, "sm_tickets.html", context)


@require_http_methods(["GET"])
def sm_unassigned(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    context = {"title": "UnAssigned Tickets"}
    return render(request, "sm_unassigned.html", context)


@require_http_methods(["GET"])
def sm_escalated(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    context = {"title": "Escalated Tickets"}
    return render(request, "sm_escalated.html", context)


@require_http_methods(["GET"])
def sm_resolved(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    context = {"title": "Resolved Tickets"}
    return render(request, "sm_resolved.html", context)


@require_http_methods(["GET"])
def eng_my_task(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    context = {"title": "My Task"}
    return render(request, "engineer_my_task.html", context)


@require_http_methods(["GET"])
def eng_escalated(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    context = {"title": "Escalated"}
    return render(request, "engineer_escalated_task.html", context)


@require_http_methods(["GET"])
def eng_resolved(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    context = {"title": "Resolved"}
    return render(request, "engineer_resolved_task.html", context)


@require_http_methods(["GET"])
def logout_view(request):
    """Clear session and redirect to login page."""
    request.session.flush()
    return redirect("/auth/login/")
