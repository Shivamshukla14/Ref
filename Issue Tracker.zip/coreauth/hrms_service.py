from django.db import connections
from typing import Optional, Dict

# Read-only HRMS lookup via cross-schema table test_app_logging.hrms
# Ensure your DB user has SELECT permissions on this schema/table.

HRMS_SCHEMA_TABLE = 'test_app_logging.hrms'


def get_employee_by_business_email(email: str) -> Optional[Dict]:
    """Return HRMS row dict for a given business_email, or None."""
    with connections['default'].cursor() as cursor:
        cursor.execute(
            f"SELECT emp_code, business_email, first_name, last_name, role, dependent_role, ra_e_code, reporting_manager "
            f"FROM {HRMS_SCHEMA_TABLE} WHERE business_email = %s",
            [email]
        )
        row = cursor.fetchone()
        if not row:
            return None
        return {
            'emp_code': row[0],
            'business_email': row[1],
            'first_name': row[2],
            'last_name': row[3],
            'role': row[4],
            'dependent_role': row[5],
            'ra_e_code': row[6],
            'reporting_manager': row[7],
        }
