from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from django.conf import settings
from django.http import HttpResponseBadRequest
from urllib.parse import urlencode

from .hrms_service import get_employee_by_business_email, list_active_employees_by_sub_lob
from .models import Role, RoleMapping
from .models import HrmsEmployee
from django.db.models import Q, Subquery, OuterRef


@require_http_methods(["GET"])
def login_view(request):
    return render(request, "login.html")


@require_http_methods(["GET"])
def azure_start(request):
    """
    Start Azure SSO by redirecting to Microsoft login URL.
    Note: For now this constructs an OAuth2 authorize URL (no token exchange implemented).
    """
    client_id = settings.AZURE_CLIENT_ID
    tenant = settings.AZURE_TENANT_ID
    redirect_uri = settings.AZURE_REDIRECT_URI
    if not client_id or not tenant:
        return HttpResponseBadRequest("Azure SSO not configured")

    auth_base = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
    query = urlencode({
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "response_mode": "query",
        "scope": "openid profile email",
        "state": "dev-state",
    })
    return redirect(f"{auth_base}?{query}")


@require_http_methods(["GET"])
def azure_callback(request):
    """
    Azure OAuth2 callback stub: prints the 'code' and directs to a landing page.
    In production, exchange code for tokens, validate, and map to HRMS user.
    """
    code = request.GET.get("code")
    if not code:
        return HttpResponseBadRequest("Missing code")

    # Stub: pretend we decoded and validated identity
    request.session["sso_code_received"] = True
    # Do not send email on login per requirement
    return redirect("/auth/user/dashboard/")


@require_http_methods(["POST"])
def bypass_login(request):
    """
    Bypass login using HRMS business_email. This sets session with emp_code and role.
    """
    email = request.POST.get("email", "").strip().lower()
    if not email:
        return HttpResponseBadRequest("Email is required")

    hrms = get_employee_by_business_email(email)
    if not hrms:
        return HttpResponseBadRequest("HRMS record not found for provided email")

    emp_code = hrms["emp_code"]

    # Map application role via RoleMapping; if missing, default to 'User' role (created if needed)
    mapping = RoleMapping.objects.filter(emp_code=emp_code).select_related("role").first()
    if not mapping:
        desired_role_name = (hrms.get("role") or "User").strip()
        if desired_role_name not in ("User", "SM1", "SM2"):
            desired_role_name = "User"
        desired_role, _ = Role.objects.get_or_create(name=desired_role_name)
        mapping = RoleMapping.objects.create(emp_code=emp_code, role=desired_role)

    # Set session values (simulate SSO-authenticated principal)
    request.session["emp_code"] = emp_code
    request.session["business_email"] = hrms["business_email"]
    request.session["role"] = mapping.role.name
    request.session["first_name"] = hrms.get("first_name")
    request.session["last_name"] = hrms.get("last_name")
    # Store sub_lob for filtering Requested For users
    if hrms.get("sub_lob"):
        request.session["sub_lob"] = hrms.get("sub_lob")

    # Do not send email on login per requirement

    # Redirect based on role
    if mapping.role.name == "User":
        return redirect("/auth/user/dashboard/")
    if mapping.role.name in ("SM1", "SM2"):
        return redirect("/auth/sm/dashboard/")
    if mapping.role.name in ("EUS1", "EUS2"):
        return redirect("/auth/eus/dashboard/")
    if mapping.role.name == "Engineer":
        return redirect("/auth/eng/my-task/")
    if mapping.role.name == "Admin":
        return redirect("/auth/admin/dashboard/")
    # Unknown role -> send to login
    return redirect("/auth/login/")
@require_http_methods(["GET"])
def admin_dashboard(request):
    role = request.session.get("role")
    if role != "Admin":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster
    from django.db.models import F
    qs = TicketMaster.objects.all()
    total = qs.count()
    open_issues = qs.exclude(status="Resolved").count()
    in_progress = qs.filter(status="In Progress").count()
    # Using updated_at as closure proxy if closed_at is not present
    resolved_with_due = qs.filter(status="Resolved").exclude(due_at__isnull=True)
    resolved_on_time = resolved_with_due.filter(updated_at__lte=F("due_at")).count()
    breached_sla = resolved_with_due.filter(updated_at__gt=F("due_at")).count()
    context = {
        "kpi_tickets": total,
        "kpi_open": open_issues,
        "kpi_in_progress": in_progress,
        "kpi_resolved_on_time": resolved_on_time,
        "kpi_breached_sla": breached_sla,
        "unassigned": [],
        "charts": {
            "priority": {"high": 0, "medium": 0, "low": 0}
        }
    }
    return render(request, "admin_dashboard.html", context)


@require_http_methods(["GET"])
def admin_roles(request):
    role = request.session.get("role")
    if role != "Admin":
        return redirect("/auth/login/")
    from .models import Role, RoleMapping, HrmsEmployee
    from django.db.models import Q
    roles = Role.objects.all().order_by("name")
    q = (request.GET.get('q') or '').strip()
    page = max(int(request.GET.get('page') or 1), 1)
    page_size = 10
    mapped_codes = list(RoleMapping.objects.values_list('emp_code', flat=True))
    base_qs = HrmsEmployee.objects.exclude(emp_code__in=mapped_codes)
    if q:
        base_qs = base_qs.filter(
            Q(emp_code__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(business_email__icontains=q)
        )
    total = base_qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    unassigned_items = base_qs.order_by('first_name', 'last_name')[start:end]
    total_pages = (total + page_size - 1) // page_size
    return render(request, "admin_roles.html", {
        "roles": roles,
        "unassigned": unassigned_items,
        "q": q,
        "page": page,
        "total": total,
        "total_pages": total_pages,
    })

@require_http_methods(["GET"])
def admin_roles_overview(request):
    role = request.session.get("role")
    if role != "Admin":
        return redirect("/auth/login/")
    from .models import HrmsEmployee, RoleMapping
    q = (request.GET.get('q') or '').strip()
    page = max(int(request.GET.get('page') or 1), 1)
    page_size = 15
    # Find emp_codes whose role matches search, if any
    role_codes = []
    if q:
        role_codes = list(RoleMapping.objects.filter(role__name__icontains=q).values_list('emp_code', flat=True))
    base_qs = HrmsEmployee.objects.all()
    if q:
        from django.db.models import Q
        base_qs = base_qs.filter(
            Q(emp_code__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(business_email__icontains=q) | Q(emp_code__in=role_codes)
        )
    total = base_qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    rows = base_qs.order_by('first_name', 'last_name')[start:end]
    # Build role map for shown rows: emp_code -> [role names]
    codes = [r.emp_code for r in rows]
    role_map = {}
    for m in RoleMapping.objects.select_related('role').filter(emp_code__in=codes):
        role_map.setdefault(m.emp_code, []).append(m.role.name)
    items = [
        {
            'emp_code': r.emp_code,
            'name': f"{r.first_name} {r.last_name}",
            'email': r.business_email,
            'role': ", ".join(role_map.get(r.emp_code, [])) if role_map.get(r.emp_code) else '—'
        }
        for r in rows
    ]
    total_pages = (total + page_size - 1) // page_size
    context = {
        'items': items,
        'q': q,
        'page': page,
        'total': total,
        'total_pages': total_pages,
    }
    return render(request, "admin_roles_overview.html", context)


@require_http_methods(["POST"])
def admin_assign_role(request):
    from django.http import JsonResponse
    role = request.session.get("role")
    if role != "Admin":
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    emp_code = (payload.get("emp_code") or "").strip()
    role_name = (payload.get("role_name") or "").strip()
    if not emp_code or not role_name:
        return JsonResponse({"ok": False, "error": "emp_code and role_name are required"}, status=400)
    from .models import Role, RoleMapping
    role_obj, _ = Role.objects.get_or_create(name=role_name)
    # Do not replace existing roles; add new mapping if not already assigned
    from django.db import IntegrityError, connection, transaction
    exists = RoleMapping.objects.filter(emp_code=emp_code, role=role_obj).exists()
    if exists:
        return JsonResponse({"ok": False, "error": f"Role '{role_obj.name}' already assigned to {emp_code}."}, status=400)
    try:
        with transaction.atomic():
            RoleMapping.objects.create(emp_code=emp_code, role=role_obj)
    except IntegrityError:
        # Handle potential sequence drift once
        try:
            with connection.cursor() as cur:
                cur.execute(
                    "SELECT setval(pg_get_serial_sequence('resolvex_role_mapping', 'id'), COALESCE((SELECT MAX(id) FROM resolvex_role_mapping), 1), true);"
                )
        except Exception:
            return JsonResponse({"ok": False, "error": "Sequence reset failed; contact admin"}, status=500)
        with transaction.atomic():
            RoleMapping.objects.create(emp_code=emp_code, role=role_obj)
    return JsonResponse({"ok": True, "assigned": True, "emp_code": emp_code, "role": role_obj.name})


@require_http_methods(["POST"])
def admin_unassign_role(request):
    from django.http import JsonResponse
    role = request.session.get("role")
    if role != "Admin":
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    emp_code = (payload.get("emp_code") or "").strip()
    role_name = (payload.get("role_name") or "").strip()
    if not emp_code:
        return JsonResponse({"ok": False, "error": "emp_code is required"}, status=400)
    from .models import Role, RoleMapping
    qs = RoleMapping.objects.filter(emp_code=emp_code)
    if role_name:
        qs = qs.filter(role__name=role_name)
    deleted, _ = qs.delete()
    return JsonResponse({"ok": True, "deleted": deleted})


@require_http_methods(["GET"])
def user_dashboard(request):
    """User dashboard KPIs computed from TicketMaster for current user."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/sm/dashboard/") if role in ("SM1", "SM2") else redirect("/auth/login/")
    from tickets.models import TicketMaster
    emp = request.session.get("emp_code")
    qs = TicketMaster.objects.filter(reported_by=emp)
    total = qs.count()
    open_issues = qs.exclude(status="Resolved").count()
    in_progress = qs.filter(status="In Progress").count()
    resolved = qs.filter(status="Resolved").count()
    context = {
        "first_name": request.session.get("first_name", ""),
        "kpi_total": total,
        "kpi_open": open_issues,
        "kpi_in_progress": in_progress,
        "kpi_resolved": resolved,
        "tickets": [],
    }
    return render(request, "user_dashboard.html", context)


@require_http_methods(["GET", "POST"])
def user_new_ticket(request):
    """Render New Ticket or handle submission with dynamic service fields."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/login/")
    from applications.models import Application
    from tickets.models import TicketMaster, TicketExtraFields, TicketAssetDetails
    from catalog.models import Service, ServiceCategory, ServiceSubCategory, ServiceSubSubCategory, PriorityMapping, SLASetting
    from django.db import transaction
    from django.utils import timezone
    from datetime import timedelta
    apps = Application.objects.all().order_by("app_name")
    services = Service.objects.filter(is_active=True).order_by("name")

    if request.method == "POST":
        # Base selections
        service_id = request.POST.get("service")
        category_id = request.POST.get("category")
        sub_category_id = request.POST.get("sub_category")
        sub_sub_category_id = request.POST.get("sub_sub_category")
        requested_for_type = request.POST.get("requested_for_type", "Self")
        requested_for_code = request.POST.get("requested_for_code")

        if not service_id or not category_id:
            return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Please select Service and Category."})
        try:
            service = Service.objects.get(pk=service_id)
            category = ServiceCategory.objects.get(pk=category_id)
            sub_cat = ServiceSubCategory.objects.get(pk=sub_category_id) if sub_category_id else None
            sub_sub = ServiceSubSubCategory.objects.get(pk=sub_sub_category_id) if sub_sub_category_id else None
        except (Service.DoesNotExist, ServiceCategory.DoesNotExist):
            return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Invalid service/category selection."})

        # Additional fields: Application Support service uses Title/Priority/Application/Description
        title = request.POST.get("title", "").strip()
        application_id = request.POST.get("application")
        # priority is auto-calculated via PriorityMapping; do not read from request
        description = request.POST.get("description", "").strip()
        app = None
        if service.name.lower() == "application support":
            if not title or not application_id or not description:
                return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Please fill Title, Application and Description for Application Support service."})
            try:
                app = Application.objects.get(pk=application_id)
            except Application.DoesNotExist:
                return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Selected application not found."})

        # Compute Priority via PriorityMapping
        pm_qs = PriorityMapping.objects.filter(service_category=category, is_active=True)
        if sub_cat:
            pm_qs = pm_qs.filter(service_sub_category=sub_cat)
        else:
            pm_qs = pm_qs.filter(service_sub_category__isnull=True)
        if sub_sub:
            pm_qs = pm_qs.filter(service_sub_sub_category=sub_sub)
        else:
            pm_qs = pm_qs.filter(service_sub_sub_category__isnull=True)
        pm = pm_qs.first()
        if not pm:
            return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Priority mapping not configured for the selected combination."})
        priority_code = pm.priority_code

        # Compute due_at via SLASetting
        sla = SLASetting.objects.filter(priority_code=priority_code).first()
        if not sla:
            return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "SLA not configured for priority %s." % priority_code})
        due_at = timezone.now() + timedelta(hours=sla.resolution_time_hours)

        # Generate ticket_id: N-<app_code>-<seq starting 1001>
        # Determine next sequence per app_code
        prefix = f"N-{(service.code)}-"
        with transaction.atomic():
            latest = TicketMaster.objects.filter(ticket_id__startswith=prefix).order_by("-issue_id").first()
            if latest and latest.ticket_id.startswith(prefix):
                try:
                    last_seq = int(latest.ticket_id.split("-")[-1])
                except ValueError:
                    last_seq = 0
            else:
                last_seq = 0
            next_seq = last_seq + 1
            ticket_id = f"{prefix}{next_seq:06d}"

            tm = TicketMaster.objects.create(
                ticket_id=ticket_id,
                app_id=app,
                service=service,
                category=category,
                sub_category=sub_cat,
                sub_sub_category=sub_sub,
                requested_for_code=(requested_for_code if requested_for_type == "Other" else request.session.get("emp_code")),
                reported_by=request.session.get("emp_code"),
                title=title,
                description=description,
                priority=priority_code,
                status="Unassigned",
                due_at=due_at,
                has_attachments=bool(request.FILES.getlist("attachments")),
            )

            # Persist End User Support extra fields, if any
            if service.name.lower() == "end user support":
                folder_path = (request.POST.get("folder_path") or "").strip()
                website = (request.POST.get("website") or "").strip()
                vpn_name = (request.POST.get("vpn_name") or "").strip()
                if folder_path:
                    TicketExtraFields.objects.create(issue_id=tm, field_key="folder_path", field_value=folder_path)
                if website:
                    TicketExtraFields.objects.create(issue_id=tm, field_key="website", field_value=website)
                if vpn_name:
                    TicketExtraFields.objects.create(issue_id=tm, field_key="vpn_name", field_value=vpn_name)

                # Optional Asset details (for Laptop/Desktop, Keyboard/Mouse, Printer/Scanner)
                asset_type = (request.POST.get("asset_type") or "").strip()
                asset_tag = (request.POST.get("asset_tag") or "").strip()
                serial_number = (request.POST.get("serial_number") or "").strip()
                if asset_type or asset_tag or serial_number:
                    TicketAssetDetails.objects.create(
                        issue_id=tm,
                        asset_type=asset_type,
                        asset_tag=asset_tag,
                        serial_number=serial_number,
                    )

        # TODO: save attachments to S3 later; for now skip persistence
        from django.contrib import messages
        messages.success(request, "Ticket submitted successfully: %s" % ticket_id)
        return redirect("/auth/user/my-tickets/")

    return render(request, "user_new_ticket.html", {"applications": apps, "services": services})


@require_http_methods(["GET"])
def user_my_tickets(request):
    """Render My Tickets with filter by Service and details pane."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/login/")

    from catalog.models import Service
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster
    from django.db.models import Prefetch

    services = Service.objects.filter(is_active=True).order_by("name")
    service_id = request.GET.get("service")
    emp_code = request.session.get("emp_code")

    selected_service = None
    if service_id:
        try:
            selected_service = services.get(pk=service_id)
        except Service.DoesNotExist:
            selected_service = None

    tickets_qs = TicketMaster.objects.filter(reported_by=emp_code).select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    if selected_service:
        tickets_qs = tickets_qs.filter(service=selected_service)

    # Build map of requested_for_code and reported_by -> full name from HRMS
    code_set = set()
    for t in tickets_qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    # Prepare lightweight dicts for template consumption
    tickets = []
    for t in tickets_qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        # Requested By label
        rb_code = t.reported_by
        rb_name = name_map.get(rb_code)
        requested_by_label = f"({rb_code}) - {rb_name}" if rb_name else rb_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            # Details
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "services": services,
        "selected_service": selected_service,
        "tickets": tickets,
    }
    return render(request, "user_my_tickets.html", context)


@require_http_methods(["GET"])
def root_redirect(request):
    """Redirect root to dashboard if logged in, else to login."""
    if request.session.get("emp_code"):
        role = request.session.get("role")
        if role == "User":
            return redirect("/auth/user/dashboard/")
        if role in ("SM1", "SM2"):
            return redirect("/auth/sm/dashboard/")
        if role in ("EUS1", "EUS2"):
            return redirect("/auth/eus/dashboard/")
        if role == "Engineer":
            return redirect("/auth/eng/my-task/")
    return redirect("/auth/login/")
@require_http_methods(["GET"])
def sm_dashboard(request):
    """Service Manager dashboard (SM1/SM2) per wireframe with static data."""
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from tickets.models import TicketMaster
    from django.db.models import F
    qs = TicketMaster.objects.filter(service__name__iexact="Application Support")
    total = qs.count()
    open_issues = qs.exclude(status="Resolved").count()
    in_progress = qs.filter(status="In Progress").count()
    resolved_with_due = qs.filter(status="Resolved").exclude(due_at__isnull=True)
    resolved_on_time = resolved_with_due.filter(updated_at__lte=F("due_at")).count()
    breached_sla = resolved_with_due.filter(updated_at__gt=F("due_at")).count()
    context = {
        "kpi_tickets": total,
        "kpi_open": open_issues,
        "kpi_in_progress": in_progress,
        "kpi_resolved_on_time": resolved_on_time,
        "kpi_breached_sla": breached_sla,
        "unassigned": [],
        "charts": {
            "priority": {"high": 0, "medium": 0, "low": 0}
        }
    }
    return render(request, "sm_dashboard.html", context)


@require_http_methods(["GET"])
def eus_dashboard(request):
    """End User Support dashboard (EUS1/EUS2) showing only End User Support tickets."""
    role = request.session.get("role")
    if role not in ("EUS1", "EUS2"):
        return redirect("/auth/login/")
    from tickets.models import TicketMaster
    from django.db.models import F
    qs = TicketMaster.objects.filter(service__name__iexact="End User Support")
    total = qs.count()
    open_issues = qs.exclude(status="Resolved").count()
    in_progress = qs.filter(status="In Progress").count()
    resolved_with_due = qs.filter(status="Resolved").exclude(due_at__isnull=True)
    resolved_on_time = resolved_with_due.filter(updated_at__lte=F("due_at")).count()
    breached_sla = resolved_with_due.filter(updated_at__gt=F("due_at")).count()
    context = {
        "kpi_tickets": total,
        "kpi_open": open_issues,
        "kpi_in_progress": in_progress,
        "kpi_resolved_on_time": resolved_on_time,
        "kpi_breached_sla": breached_sla,
        "unassigned": [],
        "charts": {
            "priority": {"high": 0, "medium": 0, "low": 0}
        }
    }
    return render(request, "eus_dashboard.html", context)


@require_http_methods(["GET"])
def sm_tickets(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(service__name__iexact="Application Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    # requested_for mapping
    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "All Tickets",
    }
    return render(request, "sm_tickets.html", context)


@require_http_methods(["GET"])
def eus_tickets(request):
    role = request.session.get("role")
    if role not in ("EUS1", "EUS2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(service__name__iexact="End User Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "All Tickets",
    }
    return render(request, "eus_tickets.html", context)


@require_http_methods(["GET"])
def sm_unassigned(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Unassigned", service__name__iexact="Application Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Unassigned Tickets",
    }
    return render(request, "sm_unassigned.html", context)


@require_http_methods(["GET"])
def eus_unassigned(request):
    role = request.session.get("role")
    if role not in ("EUS1", "EUS2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Unassigned", service__name__iexact="End User Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Unassigned Tickets",
    }
    return render(request, "eus_unassigned.html", context)


@require_http_methods(["GET"])
def sm_escalated(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Escalated", service__name__iexact="Application Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Escalated Tickets",
    }
    return render(request, "sm_escalated.html", context)


@require_http_methods(["GET"])
def eus_escalated(request):
    role = request.session.get("role")
    if role not in ("EUS1", "EUS2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Escalated", service__name__iexact="End User Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Escalated Tickets",
    }
    return render(request, "eus_escalated.html", context)


@require_http_methods(["GET"])
def sm_resolved(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Resolved", service__name__iexact="Application Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "updated_at": t.updated_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Resolved Tickets",
    }
    return render(request, "sm_resolved.html", context)


@require_http_methods(["GET"])
def eus_resolved(request):
    role = request.session.get("role")
    if role not in ("EUS1", "EUS2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Resolved", service__name__iexact="End User Support").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "updated_at": t.updated_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })
    context = {"tickets": tickets, "page_title": "Resolved Tickets"}
    return render(request, "eus_resolved.html", context)


@require_http_methods(["GET"])
def eng_my_task(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster, TicketAssignment
    from coreauth.models import HrmsEmployee
    # latest assigned_to for each ticket
    latest_assignee = TicketAssignment.objects.filter(issue_id=OuterRef('pk')).order_by('-assigned_at').values('assigned_to')[:1]
    emp_code = request.session.get('emp_code')
    qs = TicketMaster.objects.annotate(current_assignee=Subquery(latest_assignee)).filter(current_assignee=emp_code).exclude(status="Resolved").select_related(
        'app_id','service','category','sub_category','sub_sub_category'
    ).order_by('-created_at')

    # Build requested_for names
    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            'issue_id': t.issue_id,
            'ticket_id': t.ticket_id,
            'title': t.title or 'Untitled',
            'application': getattr(t.app_id, 'app_name', '-'),
            'priority': t.priority or '-',
            'status': t.status or '-',
            'created_at': t.created_at,
            'service': getattr(t.service, 'name', '-'),
            'category': getattr(t.category, 'name', '-'),
            'sub_category': getattr(t.sub_category, 'name', '-'),
            'sub_sub_category': getattr(t.sub_sub_category, 'name', '-'),
            'description': t.description or 'No description provided.',
            'requested_for': requested_for_label,
            'requested_by': requested_by_label,
        })
    context = {"tickets": tickets, "page_title": "My Task"}
    return render(request, "engineer_my_task.html", context)


@require_http_methods(["GET"])
def eng_escalated(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster, TicketAssignment
    from coreauth.models import HrmsEmployee
    latest_assignee = TicketAssignment.objects.filter(issue_id=OuterRef('pk')).order_by('-assigned_at').values('assigned_to')[:1]
    emp_code = request.session.get('emp_code')
    qs = TicketMaster.objects.annotate(current_assignee=Subquery(latest_assignee)).filter(
        current_assignee=emp_code,
        status="Escalated",
        service__name__iexact="Application Support",
    ).select_related('app_id','service','category','sub_category','sub_sub_category').order_by('-created_at')

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        # Include Requested By label similar to other views
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else (rep_code or "-")
        tickets.append({
            'issue_id': t.issue_id,
            'ticket_id': t.ticket_id,
            'title': t.title or 'Untitled',
            'application': getattr(t.app_id, 'app_name', '-'),
            'priority': t.priority or '-',
            'status': t.status or '-',
            'created_at': t.created_at,
            'service': getattr(t.service, 'name', '-'),
            'category': getattr(t.category, 'name', '-'),
            'sub_category': getattr(t.sub_category, 'name', '-'),
            'sub_sub_category': getattr(t.sub_sub_category, 'name', '-'),
            'description': t.description or 'No description provided.',
            'requested_for': requested_for_label,
            'requested_by': requested_by_label,
        })
    context = {"tickets": tickets, "page_title": "Escalated"}
    return render(request, "engineer_escalated_task.html", context)


@require_http_methods(["GET"])
def eng_resolved(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster, TicketAssignment
    from coreauth.models import HrmsEmployee

    latest_assignee = TicketAssignment.objects.filter(issue_id=OuterRef('pk')).order_by('-assigned_at').values('assigned_to')[:1]
    emp_code = request.session.get('emp_code')
    qs = TicketMaster.objects.annotate(current_assignee=Subquery(latest_assignee)).filter(
        current_assignee=emp_code,
        status="Resolved",
    ).select_related('app_id','service','category','sub_category','sub_sub_category').order_by('-updated_at', '-created_at')

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            'issue_id': t.issue_id,
            'ticket_id': t.ticket_id,
            'title': t.title or 'Untitled',
            'application': getattr(t.app_id, 'app_name', '-'),
            'priority': t.priority or '-',
            'status': t.status or '-',
            'created_at': t.created_at,
            'updated_at': t.updated_at,
            'service': getattr(t.service, 'name', '-'),
            'category': getattr(t.category, 'name', '-'),
            'sub_category': getattr(t.sub_category, 'name', '-'),
            'sub_sub_category': getattr(t.sub_sub_category, 'name', '-'),
            'description': t.description or 'No description provided.',
            'requested_for': requested_for_label,
            'requested_by': requested_by_label,
        })
    context = {"tickets": tickets, "page_title": "Resolved"}
    return render(request, "engineer_resolved_task.html", context)


@require_http_methods(["POST"])
def sm_assign_ticket(request):
    """Assign a ticket to an engineer, set status to In Progress, record assignment."""
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")
    if role not in ("SM1","SM2") or not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)

    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    issue_id = payload.get('issue_id')
    assigned_to = payload.get('assigned_to')
    override = payload.get('override') in (True, 'true', 'True', '1', 1)
    reason = payload.get('reason') or ''
    if not issue_id or not assigned_to:
        return JsonResponse({"ok": False, "error": "issue_id and assigned_to are required"}, status=400)

    from tickets.models import TicketMaster, TicketAssignment
    try:
        tm = TicketMaster.objects.get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    # Record assignment (store remark if provided; mark reassigned if override flag indicated)
    TicketAssignment.objects.create(
        issue_id=tm,
        assigned_by=emp_code,
        assigned_to=assigned_to,
        assigned_by_role=role,
        reassigned=bool(override),
        remark=reason,
    )

    # Update ticket status to In Progress
    tm.status = "In Progress"
    tm.save(update_fields=["status", "updated_at"])

    return JsonResponse({"ok": True})


@require_http_methods(["GET"])
def eus_engineers_list(request):
    """Return list of employees whose role exactly equals 'EUS_Engineer'."""
    from django.http import JsonResponse
    role = Role.objects.filter(name="EUS_Engineer").first()
    if not role:
        return JsonResponse({"results": []})
    mappings = RoleMapping.objects.filter(role=role).values_list("emp_code", flat=True)
    emps = HrmsEmployee.objects.filter(emp_code__in=list(mappings)).order_by("first_name", "last_name")
    results = [
        {"emp_code": e.emp_code, "label": f"{e.first_name} {e.last_name} ({e.emp_code})"}
        for e in emps
    ]
    return JsonResponse({"results": results})


@require_http_methods(["POST"])
def eus_assign_ticket(request):
    """Assign an End User Support ticket to an EUS engineer, set status to In Progress, record assignment."""
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")
    if role not in ("EUS1","EUS2") or not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)

    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    issue_id = payload.get('issue_id')
    assigned_to = payload.get('assigned_to')
    reason = payload.get('reason') or ''
    if not issue_id or not assigned_to:
        return JsonResponse({"ok": False, "error": "issue_id and assigned_to are required"}, status=400)

    from tickets.models import TicketMaster, TicketAssignment
    try:
        tm = TicketMaster.objects.get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    # Ensure this is End User Support ticket
    if not getattr(tm.service, 'name', '').lower() == 'end user support'.lower():
        return JsonResponse({"ok": False, "error": "Not an End User Support ticket"}, status=400)

    # Record assignment
    TicketAssignment.objects.create(
        issue_id=tm,
        assigned_by=emp_code,
        assigned_to=assigned_to,
        assigned_by_role=role,
        reassigned=False,
        remark=reason,
    )

    tm.status = "In Progress"
    tm.save(update_fields=["status", "updated_at"])

    return JsonResponse({"ok": True})


@require_http_methods(["POST"])
def sm_reassign_ticket(request):
    """Reassign a ticket to a different engineer; remark is mandatory; record assignment as reassigned."""
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")
    if role not in ("SM1","SM2") or not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)

    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    issue_id = payload.get('issue_id')
    assigned_to = payload.get('assigned_to')
    reason = (payload.get('reason') or '').strip()
    if not issue_id or not assigned_to:
        return JsonResponse({"ok": False, "error": "issue_id and assigned_to are required"}, status=400)
    if not reason:
        return JsonResponse({"ok": False, "error": "remark is required for reassign"}, status=400)

    from tickets.models import TicketMaster, TicketAssignment
    try:
        tm = TicketMaster.objects.get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    # Only allow reassign when not Unassigned or Resolved
    if tm.status in ("Unassigned", "Resolved"):
        return JsonResponse({"ok": False, "error": f"Cannot reassign when status is {tm.status}"}, status=400)

    # Enforce reassign permission rules based on last assignment
    from django.db.models import Max
    latest_assignment = TicketAssignment.objects.filter(issue_id=tm).order_by('-assigned_at').first()
    if latest_assignment:
        last_role = latest_assignment.assigned_by_role or ''
        last_by = latest_assignment.assigned_by or ''
        # Rule:
        # - If last assigned by SM2, only that SM2 (same emp_code) can reassign
        # - If last assigned by SM1, SM2 can reassign (and SM1 is also allowed)
        if last_role == 'SM2':
            if role != 'SM2' or emp_code != last_by:
                return JsonResponse({"ok": False, "error": "Only the SM2 who last assigned this ticket can reassign it."}, status=403)
        elif last_role == 'SM1':
            if role not in ('SM1','SM2'):
                return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
        else:
            # For any other last-role, restrict to SM roles
            if role not in ('SM1','SM2'):
                return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)

    # Record reassignment with mandatory remark
    TicketAssignment.objects.create(
        issue_id=tm,
        assigned_by=emp_code,
        assigned_to=assigned_to,
        assigned_by_role=role,
        reassigned=True,
        remark=reason,
    )

    # Keep status as-is (ensure not Resolved); if somehow different, set to In Progress
    if tm.status == "Unassigned":
        tm.status = "In Progress"
        tm.save(update_fields=["status", "updated_at"])

    return JsonResponse({"ok": True})


@require_http_methods(["POST"])
def resolve_ticket(request):
    """Resolve a ticket from SM or Engineer with optional comment."""
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")
    if role not in ("SM1","SM2","Engineer") or not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    issue_id = payload.get('issue_id')
    comment = (payload.get('comment') or '').strip()
    if not issue_id:
        return JsonResponse({"ok": False, "error": "issue_id is required"}, status=400)

    from tickets.models import TicketMaster, TicketComment
    try:
        tm = TicketMaster.objects.get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    if comment:
        TicketComment.objects.create(issue_id=tm, commented_by=emp_code, comment_text=comment, is_resolution=True)
    tm.status = "Resolved"
    tm.save(update_fields=["status", "updated_at"])
    return JsonResponse({"ok": True})


@require_http_methods(["GET"])
def ticket_history(request):
    """Return timeline history for a ticket: created, assignments, comments, escalations."""
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")

    issue_id = request.GET.get('issue_id')
    if not issue_id:
        return JsonResponse({"ok": False, "error": "issue_id is required"}, status=400)

    from tickets.models import TicketMaster, TicketAssignment, TicketComment, TicketEscalation
    from coreauth.models import HrmsEmployee
    try:
        tm = TicketMaster.objects.select_related('service','category','sub_category','sub_sub_category','app_id').get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    # Authorization: SM/Engineer/EUS can view any; others only if reporter/requested_for
    if role not in ("SM1","SM2","Engineer","EUS1","EUS2"):
        allowed_codes = set(filter(None, [tm.reported_by, tm.requested_for_code]))
        if not emp_code or emp_code not in allowed_codes:
            return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)

    codes = set()
    if tm.reported_by:
        codes.add(tm.reported_by)
    assignments = list(TicketAssignment.objects.filter(issue_id=tm).order_by('assigned_at').values(
        'assigned_at','assigned_by','assigned_to','assigned_by_role','remark','reassigned'
    ))
    comments = list(TicketComment.objects.filter(issue_id=tm).order_by('commented_at').values(
        'commented_at','commented_by','comment_text','is_resolution'
    ))
    escalations = list(TicketEscalation.objects.filter(issue_id=tm).order_by('escalated_at').values(
        'escalated_at','escalated_by','escalated_to','escalated_to_role','reason'
    ))
    for a in assignments:
        if a.get('assigned_by'):
            codes.add(a['assigned_by'])
        if a.get('assigned_to'):
            codes.add(a['assigned_to'])
    for c in comments:
        if c.get('commented_by'):
            codes.add(c['commented_by'])
    for e in escalations:
        if e.get('escalated_by'):
            codes.add(e['escalated_by'])
        if e.get('escalated_to'):
            codes.add(e['escalated_to'])

    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(codes))}

    timeline = []
    rep_name = name_map.get(tm.reported_by)
    timeline.append({
        "ts": tm.created_at,
        "type": "created",
        "title": "Ticket Created",
        "details": {
            "by": tm.reported_by,
            "by_name": rep_name,
            "service": getattr(tm.service,'name',None),
            "category": getattr(tm.category,'name',None),
            "sub_category": getattr(tm.sub_category,'name',None),
            "sub_sub_category": getattr(tm.sub_sub_category,'name',None),
            "application": getattr(tm.app_id,'app_name',None),
        }
    })

    for a in assignments:
        timeline.append({
            "ts": a['assigned_at'],
            "type": "assignment",
            "title": "Assigned" + (" (Reassigned)" if a.get('reassigned') else ""),
            "details": {
                "assigned_by": a.get('assigned_by'),
                "assigned_by_name": name_map.get(a.get('assigned_by')),
                "assigned_by_role": a.get('assigned_by_role'),
                "assigned_to": a.get('assigned_to'),
                "assigned_to_name": name_map.get(a.get('assigned_to')),
                "remark": a.get('remark') or "",
            }
        })

    for c in comments:
        timeline.append({
            "ts": c['commented_at'],
            "type": "comment" if not c.get('is_resolution') else "resolution_comment",
            "title": "Comment" if not c.get('is_resolution') else "Resolution Comment",
            "details": {
                "commented_by": c.get('commented_by'),
                "commented_by_name": name_map.get(c.get('commented_by')),
                "text": c.get('comment_text'),
            }
        })

    for e in escalations:
        timeline.append({
            "ts": e['escalated_at'],
            "type": "escalation",
            "title": "Escalated",
            "details": {
                "escalated_by": e.get('escalated_by'),
                "escalated_by_name": name_map.get(e.get('escalated_by')),
                "escalated_to": e.get('escalated_to'),
                "escalated_to_name": name_map.get(e.get('escalated_to')),
                "escalated_to_role": e.get('escalated_to_role'),
                "reason": e.get('reason'),
            }
        })

    timeline_sorted = sorted(timeline, key=lambda x: x["ts"]) if timeline else []

    return JsonResponse({
        "ok": True,
        "ticket": {
            "issue_id": tm.issue_id,
            "ticket_id": tm.ticket_id,
            "title": tm.title,
            "priority": tm.priority,
            "status": tm.status,
        },
        "timeline": timeline_sorted
    })


@require_http_methods(["GET"])
def logout_view(request):
    """Clear session and redirect to login page."""
    request.session.flush()
    return redirect("/auth/login/")

@require_http_methods(["GET"])
def employees_list(request):
    """Return active employees for Requested For dropdown."""
    q = request.GET.get("q", "").strip()
    sub_lob = request.session.get("sub_lob")
    # If sub_lob missing, try to fetch via HRMS using session email
    if not sub_lob and request.session.get("business_email"):
        hrms = get_employee_by_business_email(request.session.get("business_email"))
        if hrms and hrms.get("sub_lob"):
            sub_lob = hrms.get("sub_lob")
            request.session["sub_lob"] = sub_lob
    items = list_active_employees_by_sub_lob(sub_lob or "", q)
    from django.http import JsonResponse
    return JsonResponse({"results": items})

@require_http_methods(["GET"])
def compute_priority(request):
    """Compute priority code and SLA hours for a selected taxonomy combination.
    Inputs via query: category_id, sub_category_id (optional), sub_sub_category_id (optional)
    """
    from django.http import JsonResponse
    from catalog.models import ServiceCategory, ServiceSubCategory, ServiceSubSubCategory, PriorityMapping, SLASetting
    cat_id = request.GET.get("category_id")
    sub_id = request.GET.get("sub_category_id")
    subsub_id = request.GET.get("sub_sub_category_id")
    if not cat_id:
        return JsonResponse({"ok": False, "error": "category_id is required"}, status=400)
    try:
        category = ServiceCategory.objects.get(pk=cat_id)
    except ServiceCategory.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Category not found"}, status=404)
    sub_cat = None
    sub_sub = None
    if sub_id:
        try:
            sub_cat = ServiceSubCategory.objects.get(pk=sub_id)
        except ServiceSubCategory.DoesNotExist:
            return JsonResponse({"ok": False, "error": "Sub Category not found"}, status=404)
    if subsub_id:
        try:
            sub_sub = ServiceSubSubCategory.objects.get(pk=subsub_id)
        except ServiceSubSubCategory.DoesNotExist:
            return JsonResponse({"ok": False, "error": "Sub Sub Category not found"}, status=404)

    pm_qs = PriorityMapping.objects.filter(service_category=category, is_active=True)
    pm_qs = pm_qs.filter(service_sub_category=sub_cat) if sub_cat else pm_qs.filter(service_sub_category__isnull=True)
    pm_qs = pm_qs.filter(service_sub_sub_category=sub_sub) if sub_sub else pm_qs.filter(service_sub_sub_category__isnull=True)
    pm = pm_qs.first()
    if not pm:
        return JsonResponse({"ok": False, "error": "Priority mapping not configured"}, status=404)
    sla = SLASetting.objects.filter(priority_code=pm.priority_code).first()
    return JsonResponse({
        "ok": True,
        "priority_code": pm.priority_code,
        "resolution_time_hours": sla.resolution_time_hours if sla else None,
    })

@require_http_methods(["POST"])
def add_comment(request):
    """Add a comment to a ticket from slide-out drawers.
    Allowed roles: User (only own tickets), SM1, SM2 (any ticket).
    """
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")
    if role not in ("User", "SM1", "SM2", "Engineer", "EUS1", "EUS2") or not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    issue_id = payload.get('issue_id')
    comment = (payload.get('comment') or '').strip()
    if not issue_id or not comment:
        return JsonResponse({"ok": False, "error": "issue_id and comment are required"}, status=400)

    from tickets.models import TicketMaster, TicketComment, TicketAssignment
    try:
        tm = TicketMaster.objects.get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    # Ensure User can only comment on their own reported tickets
    if role == "User" and tm.reported_by != emp_code:
        return JsonResponse({"ok": False, "error": "Forbidden"}, status=403)

    # Ensure Engineer can only comment on tickets currently assigned to them
    if role == "Engineer":
        latest_assignment = TicketAssignment.objects.filter(issue_id=tm).order_by('-assigned_at').first()
        if not latest_assignment or latest_assignment.assigned_to != emp_code:
            return JsonResponse({"ok": False, "error": "Forbidden"}, status=403)

    # Enforce server-side 200-letter (character) limit
    if len(comment) > 200:
        return JsonResponse({"ok": False, "error": "Comment exceeds 200 letters"}, status=400)

    TicketComment.objects.create(issue_id=tm, commented_by=emp_code, comment_text=comment, is_resolution=False)
    return JsonResponse({"ok": True})

@require_http_methods(["GET"])
def engineers_list(request):
    """Return list of Engineers based on RoleMapping -> Role(name='Engineer')."""
    from django.http import JsonResponse
    try:
        role = Role.objects.get(name="Engineer")
    except Role.DoesNotExist:
        return JsonResponse({"results": []})

    mappings = RoleMapping.objects.filter(role=role).values_list("emp_code", flat=True)
    emps = HrmsEmployee.objects.filter(emp_code__in=list(mappings)).order_by("first_name", "last_name")
    results = [
        {
            "emp_code": e.emp_code,
            "label": f"{e.first_name} {e.last_name} ({e.emp_code})",
        }
        for e in emps
    ]
    return JsonResponse({"results": results})


@require_http_methods(["GET"])
def my_roles(request):
    from django.http import JsonResponse
    emp_code = request.session.get("emp_code")
    if not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    from .models import RoleMapping
    role_names = list(RoleMapping.objects.filter(emp_code=emp_code).select_related('role').values_list('role__name', flat=True))
    # Keep unique order
    seen = set()
    roles_unique = []
    for r in role_names:
        if r not in seen:
            roles_unique.append(r)
            seen.add(r)
    return JsonResponse({"ok": True, "roles": roles_unique, "active": request.session.get("role")})


@require_http_methods(["POST"])
def switch_role(request):
    from django.http import JsonResponse
    import json
    emp_code = request.session.get("emp_code")
    if not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    target = (payload.get('role') or '').strip()
    if not target:
        return JsonResponse({"ok": False, "error": "role is required"}, status=400)
    from .models import RoleMapping
    assigned = set(RoleMapping.objects.filter(emp_code=emp_code).select_related('role').values_list('role__name', flat=True))
    if target not in assigned:
        return JsonResponse({"ok": False, "error": "Role not assigned"}, status=403)
    request.session['role'] = target
    # Compute redirect for role
    redirect_map = {
        'User': '/auth/user/dashboard/',
        'SM1': '/auth/sm/dashboard/',
        'SM2': '/auth/sm/dashboard/',
        'EUS1': '/auth/eus/dashboard/',
        'EUS2': '/auth/eus/dashboard/',
        'Engineer': '/auth/eng/my-task/',
        'Admin': '/auth/admin/dashboard/',
    }
    return JsonResponse({"ok": True, "redirect": redirect_map.get(target, '/auth/login/')})


@require_http_methods(["GET"])
def admin_priority(request):
    """Admin page to manage Priority Mappings across service taxonomy.
    Allows selecting Service/Category/SubCategory/SubSubCategory, choosing Impact and Urgency (1-4),
    auto-computes priority code (P1-P4), and saves mapping.
    """
    role = request.session.get("role")
    if role != "Admin":
        return redirect("/auth/login/")
    from catalog.models import Service
    services = Service.objects.filter(is_active=True).order_by("name")
    return render(request, "admin_priority.html", {"services": services})


@require_http_methods(["POST"]) 
def admin_priority_save(request):
    from django.http import JsonResponse
    role = request.session.get("role")
    if role != "Admin":
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    from catalog.models import ServiceCategory, ServiceSubCategory, ServiceSubSubCategory, PriorityMapping
    # Extract payload
    service_category_id = request.POST.get("category_id")
    service_sub_category_id = request.POST.get("sub_category_id")
    service_sub_sub_category_id = request.POST.get("sub_sub_category_id")
    impact = request.POST.get("impact")
    urgency = request.POST.get("urgency")
    is_active = request.POST.get("is_active", "true").lower() == "true"
    # Validate
    if not service_category_id or not impact or not urgency:
        return JsonResponse({"ok": False, "error": "category_id, impact and urgency are required"}, status=400)
    try:
        category = ServiceCategory.objects.get(pk=service_category_id)
    except ServiceCategory.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Category not found"}, status=404)
    sub_cat = None
    sub_sub = None
    if service_sub_category_id:
        try:
            sub_cat = ServiceSubCategory.objects.get(pk=service_sub_category_id)
        except ServiceSubCategory.DoesNotExist:
            return JsonResponse({"ok": False, "error": "Sub Category not found"}, status=404)
    if service_sub_sub_category_id:
        try:
            sub_sub = ServiceSubSubCategory.objects.get(pk=service_sub_sub_category_id)
        except ServiceSubSubCategory.DoesNotExist:
            return JsonResponse({"ok": False, "error": "Sub Sub Category not found"}, status=404)
    try:
        impact_i = int(impact); urgency_i = int(urgency)
        if impact_i < 1 or impact_i > 4 or urgency_i < 1 or urgency_i > 4:
            raise ValueError()
    except Exception:
        return JsonResponse({"ok": False, "error": "impact and urgency must be integers between 1 and 4"}, status=400)

    # ITSM rule: product thresholds to P-code
    product = impact_i * urgency_i
    if product >= 12:
        priority_code = "P1"
    elif product >= 8:
        priority_code = "P2"
    elif product >= 4:
        priority_code = "P3"
    else:
        priority_code = "P4"

    # Upsert mapping per unique combination (category/sub/subsub)
    obj, created = PriorityMapping.objects.get_or_create(
        service_category=category,
        service_sub_category=sub_cat,
        service_sub_sub_category=sub_sub,
        defaults={
            "impact": impact_i,
            "urgency": urgency_i,
            "priority_code": priority_code,
            "is_active": is_active,
        }
    )
    if not created:
        obj.impact = impact_i
        obj.urgency = urgency_i
        obj.priority_code = priority_code
        obj.is_active = is_active
        obj.save(update_fields=["impact", "urgency", "priority_code", "is_active"])
    return JsonResponse({"ok": True, "created": created, "priority_code": priority_code})


@require_http_methods(["GET"])
def admin_priority_list(request):
    from django.http import JsonResponse
    role = request.session.get("role")
    if role != "Admin":
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    from catalog.models import PriorityMapping
    category_id = request.GET.get("category_id")
    sub_category_id = request.GET.get("sub_category_id")
    sub_sub_category_id = request.GET.get("sub_sub_category_id")
    qs = PriorityMapping.objects.select_related("service_category", "service_sub_category", "service_sub_sub_category").all().order_by("service_category__service__name", "service_category__name")
    if category_id:
        qs = qs.filter(service_category_id=category_id)
    if sub_category_id:
        qs = qs.filter(service_sub_category_id=sub_category_id)
    if sub_sub_category_id:
        qs = qs.filter(service_sub_sub_category_id=sub_sub_category_id)
    results = []
    for pm in qs[:500]:
        results.append({
            "id": pm.id,
            "service": pm.service_category.service.name,
            "category": pm.service_category.name,
            "sub_category": pm.service_sub_category.name if pm.service_sub_category else None,
            "sub_sub_category": pm.service_sub_sub_category.name if pm.service_sub_sub_category else None,
            "impact": pm.impact,
            "urgency": pm.urgency,
            "priority_code": pm.priority_code,
            "is_active": pm.is_active,
        })
    return JsonResponse({"ok": True, "results": results})
