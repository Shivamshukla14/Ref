from django.db import connections
from typing import Optional, Dict

# Read-only HRMS lookup via cross-schema table test_app_logging.hrms
# Ensure your DB user has SELECT permissions on this schema/table.

HRMS_SCHEMA_TABLE = 'test_app_logging.hrms'


def get_employee_by_business_email(email: str) -> Optional[Dict]:
    """Return HRMS row dict for a given business_email, or None."""
    with connections['default'].cursor() as cursor:
        cursor.execute(
            f"SELECT emp_code, business_email, first_name, last_name, role, dependent_role, ra_e_code, reporting_manager, sub_lob, employee_status "
            f"FROM {HRMS_SCHEMA_TABLE} WHERE business_email = %s",
            [email]
        )
        row = cursor.fetchone()
        if not row:
            return None
        return {
            'emp_code': row[0],
            'business_email': row[1],
            'first_name': row[2],
            'last_name': row[3],
            'role': row[4],
            'dependent_role': row[5],
            'ra_e_code': row[6],
            'reporting_manager': row[7],
            'sub_lob': row[8],
            'employee_status': row[9],
        }

def list_active_employees_by_sub_lob(sub_lob: str, query: str = "") -> list[Dict]:
    """Return employees in the same sub_lob with employee_status = 'A'. Optional name/code filter."""
    sql = (
        f"SELECT emp_code, first_name, last_name "
        f"FROM {HRMS_SCHEMA_TABLE} "
        f"WHERE employee_status = 'A' AND sub_lob = %s"
    )
    params = [sub_lob]
    if query:
        sql += " AND (LOWER(first_name) LIKE %s OR LOWER(last_name) LIKE %s OR LOWER(emp_code) LIKE %s)"
        q = f"%{query.lower()}%"
        params.extend([q, q, q])
    sql += " ORDER BY first_name, last_name LIMIT 200"
    with connections['default'].cursor() as cursor:
        cursor.execute(sql, params)
        rows = cursor.fetchall()
    return [{"emp_code": r[0], "full_name": f"{r[1]} {r[2]}"} for r in rows]
