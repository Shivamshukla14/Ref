from celery import shared_task
from django.db import transaction
from django.utils import timezone

@shared_task
def escalate_sla_breaches():
    """Auto-escalate tickets that breached SLA (due_at passed and not Resolved/Escalated).
    - Creates one TicketEscalation record per ticket if not already present (unresolved)
    - Updates TicketMaster.status to 'Escalated'
    """
    from tickets.models import TicketMaster, TicketEscalation

    now = timezone.now()
    # Select candidates: due date passed, not already Resolved/Escalated
    candidates = TicketMaster.objects.filter(due_at__isnull=False, due_at__lt=now).exclude(status__in=["Resolved", "Escalated"]).only("issue_id", "ticket_id", "status")

    for t in candidates:
        with transaction.atomic():
            # Prevent duplicate escalation rows on repeated runs
            exists = TicketEscalation.objects.select_for_update().filter(issue_id=t, resolved=False).exists()
            if not exists:
                TicketEscalation.objects.create(
                    issue_id=t,
                    escalated_to="SYSTEM",
                    escalated_to_role="SM1",
                    escalated_by="SYSTEM",
                    reason="Auto escalation due to SLA breach",
                    resolved=False,
                )
            t.status = "Escalated"
            t.save(update_fields=["status", "updated_at"]) 
