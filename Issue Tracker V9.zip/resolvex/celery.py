import os
from celery import Celery
from celery.schedules import crontab

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "resolvex.settings")

app = Celery("resolvex")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

# Run SLA escalation check every 5 minutes
app.conf.beat_schedule = {
    "sla_escalation_every_5min": {
        "task": "tickets.tasks.escalate_sla_breaches",
        "schedule": crontab(minute="*/5"),
    }
}
