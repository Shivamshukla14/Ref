from django.db import models

class TicketMaster(models.Model):
    issue_id = models.AutoField(primary_key=True)
    ticket_id = models.CharField(max_length=30, unique=True)
    app_id = models.ForeignKey('applications.Application', on_delete=models.PROTECT)
    reported_by = models.CharField(max_length=10)  # HRMS emp_code reference
    title = models.CharField(max_length=255)
    description = models.TextField()
    priority = models.CharField(max_length=15)
    status = models.CharField(max_length=50, default='Unassigned')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    due_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    has_attachments = models.BooleanField(default=False)

    class Meta:
        db_table = 'ticket_master'

    def __str__(self):
        return f"{self.ticket_id} - {self.title}"

class TicketAttachment(models.Model):
    attachment_id = models.AutoField(primary_key=True)
    issue = models.ForeignKey(TicketMaster, on_delete=models.CASCADE)
    file_name = models.TextField()
    s3_path = models.TextField(blank=True)
    uploaded_by = models.CharField(max_length=10)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_attachments'

    def __str__(self):
        return f"{self.issue_id} - {self.file_name}"
