from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from django.conf import settings
from django.http import HttpResponseBadRequest
from urllib.parse import urlencode

from .hrms_service import get_employee_by_business_email, list_active_employees_by_sub_lob
from .models import Role, RoleMapping
from .models import HrmsEmployee
from django.db.models import Q, Subquery, OuterRef


@require_http_methods(["GET"])
def login_view(request):
    return render(request, "login.html")


@require_http_methods(["GET"])
def azure_start(request):
    """
    Start Azure SSO by redirecting to Microsoft login URL.
    Note: For now this constructs an OAuth2 authorize URL (no token exchange implemented).
    """
    client_id = settings.AZURE_CLIENT_ID
    tenant = settings.AZURE_TENANT_ID
    redirect_uri = settings.AZURE_REDIRECT_URI
    if not client_id or not tenant:
        return HttpResponseBadRequest("Azure SSO not configured")

    auth_base = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
    query = urlencode({
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "response_mode": "query",
        "scope": "openid profile email",
        "state": "dev-state",
    })
    return redirect(f"{auth_base}?{query}")


@require_http_methods(["GET"])
def azure_callback(request):
    """
    Azure OAuth2 callback stub: prints the 'code' and directs to a landing page.
    In production, exchange code for tokens, validate, and map to HRMS user.
    """
    code = request.GET.get("code")
    if not code:
        return HttpResponseBadRequest("Missing code")

    # Stub: pretend we decoded and validated identity
    request.session["sso_code_received"] = True
    # Do not send email on login per requirement
    return redirect("/auth/user/dashboard/")


@require_http_methods(["POST"])
def bypass_login(request):
    """
    Bypass login using HRMS business_email. This sets session with emp_code and role.
    """
    email = request.POST.get("email", "").strip().lower()
    if not email:
        return HttpResponseBadRequest("Email is required")

    hrms = get_employee_by_business_email(email)
    if not hrms:
        return HttpResponseBadRequest("HRMS record not found for provided email")

    emp_code = hrms["emp_code"]

    # Map application role via RoleMapping; if missing, default to 'User' role (created if needed)
    mapping = RoleMapping.objects.filter(emp_code=emp_code).select_related("role").first()
    if not mapping:
        desired_role_name = (hrms.get("role") or "User").strip()
        if desired_role_name not in ("User", "SM1", "SM2"):
            desired_role_name = "User"
        desired_role, _ = Role.objects.get_or_create(name=desired_role_name)
        mapping = RoleMapping.objects.create(emp_code=emp_code, role=desired_role)

    # Set session values (simulate SSO-authenticated principal)
    request.session["emp_code"] = emp_code
    request.session["business_email"] = hrms["business_email"]
    request.session["role"] = mapping.role.name
    request.session["first_name"] = hrms.get("first_name")
    request.session["last_name"] = hrms.get("last_name")
    # Store sub_lob for filtering Requested For users
    if hrms.get("sub_lob"):
        request.session["sub_lob"] = hrms.get("sub_lob")

    # Do not send email on login per requirement

    # Redirect based on role
    if mapping.role.name == "User":
        return redirect("/auth/user/dashboard/")
    if mapping.role.name in ("SM1", "SM2"):
        return redirect("/auth/sm/dashboard/")
    if mapping.role.name == "Engineer":
        return redirect("/auth/eng/my-task/")
    if mapping.role.name == "Admin":
        return redirect("/auth/admin/dashboard/")
    # Unknown role -> send to login
    return redirect("/auth/login/")
@require_http_methods(["GET"])
def admin_dashboard(request):
    role = request.session.get("role")
    if role != "Admin":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster
    from django.db.models import F
    qs = TicketMaster.objects.all()
    total = qs.count()
    open_issues = qs.exclude(status="Resolved").count()
    in_progress = qs.filter(status="In Progress").count()
    # Using updated_at as closure proxy if closed_at is not present
    resolved_with_due = qs.filter(status="Resolved").exclude(due_at__isnull=True)
    resolved_on_time = resolved_with_due.filter(updated_at__lte=F("due_at")).count()
    breached_sla = resolved_with_due.filter(updated_at__gt=F("due_at")).count()
    context = {
        "kpi_tickets": total,
        "kpi_open": open_issues,
        "kpi_in_progress": in_progress,
        "kpi_resolved_on_time": resolved_on_time,
        "kpi_breached_sla": breached_sla,
        "unassigned": [],
        "charts": {
            "priority": {"high": 0, "medium": 0, "low": 0}
        }
    }
    return render(request, "admin_dashboard.html", context)


@require_http_methods(["GET"])
def admin_roles(request):
    role = request.session.get("role")
    if role != "Admin":
        return redirect("/auth/login/")
    from .models import Role, RoleMapping, HrmsEmployee
    from django.db.models import Q
    roles = Role.objects.all().order_by("name")
    q = (request.GET.get('q') or '').strip()
    page = max(int(request.GET.get('page') or 1), 1)
    page_size = 10
    mapped_codes = list(RoleMapping.objects.values_list('emp_code', flat=True))
    base_qs = HrmsEmployee.objects.exclude(emp_code__in=mapped_codes)
    if q:
        base_qs = base_qs.filter(
            Q(emp_code__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(business_email__icontains=q)
        )
    total = base_qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    unassigned_items = base_qs.order_by('first_name', 'last_name')[start:end]
    total_pages = (total + page_size - 1) // page_size
    return render(request, "admin_roles.html", {
        "roles": roles,
        "unassigned": unassigned_items,
        "q": q,
        "page": page,
        "total": total,
        "total_pages": total_pages,
    })

@require_http_methods(["GET"])
def admin_roles_overview(request):
    role = request.session.get("role")
    if role != "Admin":
        return redirect("/auth/login/")
    from .models import HrmsEmployee, RoleMapping
    q = (request.GET.get('q') or '').strip()
    page = max(int(request.GET.get('page') or 1), 1)
    page_size = 15
    # Find emp_codes whose role matches search, if any
    role_codes = []
    if q:
        role_codes = list(RoleMapping.objects.filter(role__name__icontains=q).values_list('emp_code', flat=True))
    base_qs = HrmsEmployee.objects.all()
    if q:
        from django.db.models import Q
        base_qs = base_qs.filter(
            Q(emp_code__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(business_email__icontains=q) | Q(emp_code__in=role_codes)
        )
    total = base_qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    rows = base_qs.order_by('first_name', 'last_name')[start:end]
    # Build role map for shown rows: emp_code -> [role names]
    codes = [r.emp_code for r in rows]
    role_map = {}
    for m in RoleMapping.objects.select_related('role').filter(emp_code__in=codes):
        role_map.setdefault(m.emp_code, []).append(m.role.name)
    items = [
        {
            'emp_code': r.emp_code,
            'name': f"{r.first_name} {r.last_name}",
            'email': r.business_email,
            'role': ", ".join(role_map.get(r.emp_code, [])) if role_map.get(r.emp_code) else '—'
        }
        for r in rows
    ]
    total_pages = (total + page_size - 1) // page_size
    context = {
        'items': items,
        'q': q,
        'page': page,
        'total': total,
        'total_pages': total_pages,
    }
    return render(request, "admin_roles_overview.html", context)


@require_http_methods(["POST"])
def admin_assign_role(request):
    from django.http import JsonResponse
    role = request.session.get("role")
    if role != "Admin":
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    emp_code = (payload.get("emp_code") or "").strip()
    role_name = (payload.get("role_name") or "").strip()
    if not emp_code or not role_name:
        return JsonResponse({"ok": False, "error": "emp_code and role_name are required"}, status=400)
    from .models import Role, RoleMapping
    role_obj, _ = Role.objects.get_or_create(name=role_name)
    # Do not replace existing roles; add new mapping if not already assigned
    from django.db import IntegrityError, connection, transaction
    exists = RoleMapping.objects.filter(emp_code=emp_code, role=role_obj).exists()
    if exists:
        return JsonResponse({"ok": False, "error": f"Role '{role_obj.name}' already assigned to {emp_code}."}, status=400)
    try:
        with transaction.atomic():
            RoleMapping.objects.create(emp_code=emp_code, role=role_obj)
    except IntegrityError:
        # Handle potential sequence drift once
        try:
            with connection.cursor() as cur:
                cur.execute(
                    "SELECT setval(pg_get_serial_sequence('resolvex_role_mapping', 'id'), COALESCE((SELECT MAX(id) FROM resolvex_role_mapping), 1), true);"
                )
        except Exception:
            return JsonResponse({"ok": False, "error": "Sequence reset failed; contact admin"}, status=500)
        with transaction.atomic():
            RoleMapping.objects.create(emp_code=emp_code, role=role_obj)
    return JsonResponse({"ok": True, "assigned": True, "emp_code": emp_code, "role": role_obj.name})


@require_http_methods(["POST"])
def admin_unassign_role(request):
    from django.http import JsonResponse
    role = request.session.get("role")
    if role != "Admin":
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    emp_code = (payload.get("emp_code") or "").strip()
    role_name = (payload.get("role_name") or "").strip()
    if not emp_code:
        return JsonResponse({"ok": False, "error": "emp_code is required"}, status=400)
    from .models import Role, RoleMapping
    qs = RoleMapping.objects.filter(emp_code=emp_code)
    if role_name:
        qs = qs.filter(role__name=role_name)
    deleted, _ = qs.delete()
    return JsonResponse({"ok": True, "deleted": deleted})


@require_http_methods(["GET"])
def user_dashboard(request):
    """User dashboard KPIs computed from TicketMaster for current user."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/sm/dashboard/") if role in ("SM1", "SM2") else redirect("/auth/login/")
    from tickets.models import TicketMaster
    emp = request.session.get("emp_code")
    qs = TicketMaster.objects.filter(reported_by=emp)
    total = qs.count()
    open_issues = qs.exclude(status="Resolved").count()
    in_progress = qs.filter(status="In Progress").count()
    resolved = qs.filter(status="Resolved").count()
    context = {
        "first_name": request.session.get("first_name", ""),
        "kpi_total": total,
        "kpi_open": open_issues,
        "kpi_in_progress": in_progress,
        "kpi_resolved": resolved,
        "tickets": [],
    }
    return render(request, "user_dashboard.html", context)


@require_http_methods(["GET", "POST"])
def user_new_ticket(request):
    """Render New Ticket or handle submission with dynamic service fields."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/login/")
    from applications.models import Application
    from tickets.models import TicketMaster
    from catalog.models import Service, ServiceCategory, ServiceSubCategory, ServiceSubSubCategory
    from django.db import transaction
    apps = Application.objects.all().order_by("app_name")
    services = Service.objects.filter(is_active=True).order_by("name")

    if request.method == "POST":
        # Base selections
        service_id = request.POST.get("service")
        category_id = request.POST.get("category")
        sub_category_id = request.POST.get("sub_category")
        sub_sub_category_id = request.POST.get("sub_sub_category")
        requested_for_type = request.POST.get("requested_for_type", "Self")
        requested_for_code = request.POST.get("requested_for_code")

        if not service_id or not category_id:
            return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Please select Service and Category."})
        try:
            service = Service.objects.get(pk=service_id)
            category = ServiceCategory.objects.get(pk=category_id)
            sub_cat = ServiceSubCategory.objects.get(pk=sub_category_id) if sub_category_id else None
            sub_sub = ServiceSubSubCategory.objects.get(pk=sub_sub_category_id) if sub_sub_category_id else None
        except (Service.DoesNotExist, ServiceCategory.DoesNotExist):
            return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Invalid service/category selection."})

        # Additional fields: Software service uses Title/Priority/Application/Description
        title = request.POST.get("title", "").strip()
        application_id = request.POST.get("application")
        priority = request.POST.get("priority")
        description = request.POST.get("description", "").strip()
        app = None
        if service.name.lower() == "software":
            if not title or not application_id or not priority or not description:
                return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Please fill Title, Application, Priority and Description for Software service."})
            try:
                app = Application.objects.get(pk=application_id)
            except Application.DoesNotExist:
                return render(request, "user_new_ticket.html", {"applications": apps, "services": services, "error": "Selected application not found."})

        # Generate ticket_id: N-<app_code>-<seq starting 1001>
        # Determine next sequence per app_code
        prefix = f"N-{(service.code)}-"
        with transaction.atomic():
            latest = TicketMaster.objects.filter(ticket_id__startswith=prefix).order_by("-issue_id").first()
            if latest and latest.ticket_id.startswith(prefix):
                try:
                    last_seq = int(latest.ticket_id.split("-")[-1])
                except ValueError:
                    last_seq = 0
            else:
                last_seq = 0
            next_seq = last_seq + 1
            ticket_id = f"{prefix}{next_seq:06d}"

            tm = TicketMaster.objects.create(
                ticket_id=ticket_id,
                app_id=app,
                service=service,
                category=category,
                sub_category=sub_cat,
                sub_sub_category=sub_sub,
                requested_for_code=(requested_for_code if requested_for_type == "Other" else request.session.get("emp_code")),
                reported_by=request.session.get("emp_code"),
                title=title,
                description=description,
                priority=priority,
                status="Unassigned",
                has_attachments=bool(request.FILES.getlist("attachments")),
            )

        # TODO: save attachments to S3 later; for now skip persistence
        from django.contrib import messages
        messages.success(request, "Ticket submitted successfully: %s" % ticket_id)
        return redirect("/auth/user/my-tickets/")

    return render(request, "user_new_ticket.html", {"applications": apps, "services": services})


@require_http_methods(["GET"])
def user_my_tickets(request):
    """Render My Tickets with filter by Service and details pane."""
    role = request.session.get("role")
    if role != "User":
        return redirect("/auth/login/")

    from catalog.models import Service
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster
    from django.db.models import Prefetch

    services = Service.objects.filter(is_active=True).order_by("name")
    service_id = request.GET.get("service")
    emp_code = request.session.get("emp_code")

    selected_service = None
    if service_id:
        try:
            selected_service = services.get(pk=service_id)
        except Service.DoesNotExist:
            selected_service = None

    tickets_qs = TicketMaster.objects.filter(reported_by=emp_code).select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    if selected_service:
        tickets_qs = tickets_qs.filter(service=selected_service)

    # Build map of requested_for_code -> full name from HRMS
    code_set = set(
        [t.requested_for_code for t in tickets_qs if t.requested_for_code]
    )
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    # Prepare lightweight dicts for template consumption
    tickets = []
    for t in tickets_qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            # Details
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
        })

    context = {
        "services": services,
        "selected_service": selected_service,
        "tickets": tickets,
    }
    return render(request, "user_my_tickets.html", context)


@require_http_methods(["GET"])
def root_redirect(request):
    """Redirect root to dashboard if logged in, else to login."""
    if request.session.get("emp_code"):
        role = request.session.get("role")
        if role == "User":
            return redirect("/auth/user/dashboard/")
        if role in ("SM1", "SM2"):
            return redirect("/auth/sm/dashboard/")
        if role == "Engineer":
            return redirect("/auth/eng/my-task/")
    return redirect("/auth/login/")
@require_http_methods(["GET"])
def sm_dashboard(request):
    """Service Manager dashboard (SM1/SM2) per wireframe with static data."""
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from tickets.models import TicketMaster
    from django.db.models import F
    qs = TicketMaster.objects.filter(service__name__iexact="Software")
    total = qs.count()
    open_issues = qs.exclude(status="Resolved").count()
    in_progress = qs.filter(status="In Progress").count()
    resolved_with_due = qs.filter(status="Resolved").exclude(due_at__isnull=True)
    resolved_on_time = resolved_with_due.filter(updated_at__lte=F("due_at")).count()
    breached_sla = resolved_with_due.filter(updated_at__gt=F("due_at")).count()
    context = {
        "kpi_tickets": total,
        "kpi_open": open_issues,
        "kpi_in_progress": in_progress,
        "kpi_resolved_on_time": resolved_on_time,
        "kpi_breached_sla": breached_sla,
        "unassigned": [],
        "charts": {
            "priority": {"high": 0, "medium": 0, "low": 0}
        }
    }
    return render(request, "sm_dashboard.html", context)


@require_http_methods(["GET"])
def sm_tickets(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(service__name__iexact="Software").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    # requested_for mapping
    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "All Tickets",
    }
    return render(request, "sm_tickets.html", context)


@require_http_methods(["GET"])
def sm_unassigned(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Unassigned", service__name__iexact="Software").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Unassigned Tickets",
    }
    return render(request, "sm_unassigned.html", context)


@require_http_methods(["GET"])
def sm_escalated(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Escalated", service__name__iexact="Software").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Escalated Tickets",
    }
    return render(request, "sm_escalated.html", context)


@require_http_methods(["GET"])
def sm_resolved(request):
    role = request.session.get("role")
    if role not in ("SM1", "SM2"):
        return redirect("/auth/login/")
    from coreauth.models import HrmsEmployee
    from tickets.models import TicketMaster

    qs = TicketMaster.objects.filter(status="Resolved", service__name__iexact="Software").select_related(
        "app_id", "service", "category", "sub_category", "sub_sub_category"
    ).order_by("-created_at")

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            "issue_id": t.issue_id,
            "ticket_id": t.ticket_id,
            "title": t.title or "Untitled",
            "application": getattr(t.app_id, "app_name", "-"),
            "priority": t.priority or "-",
            "status": t.status or "-",
            "created_at": t.created_at,
            "updated_at": t.updated_at,
            "service": getattr(t.service, "name", "-"),
            "category": getattr(t.category, "name", "-"),
            "sub_category": getattr(t.sub_category, "name", "-"),
            "sub_sub_category": getattr(t.sub_sub_category, "name", "-"),
            "description": t.description or "No description provided.",
            "requested_for": requested_for_label,
            "requested_by": requested_by_label,
        })

    context = {
        "tickets": tickets,
        "page_title": "Resolved Tickets",
    }
    return render(request, "sm_resolved.html", context)


@require_http_methods(["GET"])
def eng_my_task(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster, TicketAssignment
    from coreauth.models import HrmsEmployee
    # latest assigned_to for each ticket
    latest_assignee = TicketAssignment.objects.filter(issue_id=OuterRef('pk')).order_by('-assigned_at').values('assigned_to')[:1]
    emp_code = request.session.get('emp_code')
    qs = TicketMaster.objects.annotate(current_assignee=Subquery(latest_assignee)).filter(current_assignee=emp_code).select_related(
        'app_id','service','category','sub_category','sub_sub_category'
    ).order_by('-created_at')

    # Build requested_for names
    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            'issue_id': t.issue_id,
            'ticket_id': t.ticket_id,
            'title': t.title or 'Untitled',
            'application': getattr(t.app_id, 'app_name', '-'),
            'priority': t.priority or '-',
            'status': t.status or '-',
            'created_at': t.created_at,
            'service': getattr(t.service, 'name', '-'),
            'category': getattr(t.category, 'name', '-'),
            'sub_category': getattr(t.sub_category, 'name', '-'),
            'sub_sub_category': getattr(t.sub_sub_category, 'name', '-'),
            'description': t.description or 'No description provided.',
            'requested_for': requested_for_label,
            'requested_by': requested_by_label,
        })
    context = {"tickets": tickets, "page_title": "My Task"}
    return render(request, "engineer_my_task.html", context)


@require_http_methods(["GET"])
def eng_escalated(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster, TicketAssignment
    from coreauth.models import HrmsEmployee
    latest_assignee = TicketAssignment.objects.filter(issue_id=OuterRef('pk')).order_by('-assigned_at').values('assigned_to')[:1]
    emp_code = request.session.get('emp_code')
    qs = TicketMaster.objects.annotate(current_assignee=Subquery(latest_assignee)).filter(
        current_assignee=emp_code,
        status="Escalated",
        service__name__iexact="Software",
    ).select_related('app_id','service','category','sub_category','sub_sub_category').order_by('-created_at')

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        # Include Requested By label similar to other views
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else (rep_code or "-")
        tickets.append({
            'issue_id': t.issue_id,
            'ticket_id': t.ticket_id,
            'title': t.title or 'Untitled',
            'application': getattr(t.app_id, 'app_name', '-'),
            'priority': t.priority or '-',
            'status': t.status or '-',
            'created_at': t.created_at,
            'service': getattr(t.service, 'name', '-'),
            'category': getattr(t.category, 'name', '-'),
            'sub_category': getattr(t.sub_category, 'name', '-'),
            'sub_sub_category': getattr(t.sub_sub_category, 'name', '-'),
            'description': t.description or 'No description provided.',
            'requested_for': requested_for_label,
            'requested_by': requested_by_label,
        })
    context = {"tickets": tickets, "page_title": "Escalated"}
    return render(request, "engineer_escalated_task.html", context)


@require_http_methods(["GET"])
def eng_resolved(request):
    role = request.session.get("role")
    if role != "Engineer":
        return redirect("/auth/login/")
    from tickets.models import TicketMaster, TicketAssignment
    from coreauth.models import HrmsEmployee

    latest_assignee = TicketAssignment.objects.filter(issue_id=OuterRef('pk')).order_by('-assigned_at').values('assigned_to')[:1]
    emp_code = request.session.get('emp_code')
    qs = TicketMaster.objects.annotate(current_assignee=Subquery(latest_assignee)).filter(
        current_assignee=emp_code,
        status="Resolved",
    ).select_related('app_id','service','category','sub_category','sub_sub_category').order_by('-updated_at', '-created_at')

    code_set = set()
    for t in qs:
        if t.requested_for_code:
            code_set.add(t.requested_for_code)
        if t.reported_by:
            code_set.add(t.reported_by)
    name_map = {e.emp_code: f"{e.first_name} {e.last_name}" for e in HrmsEmployee.objects.filter(emp_code__in=list(code_set))}

    tickets = []
    for t in qs:
        req_code = t.requested_for_code or t.reported_by
        req_name = name_map.get(req_code)
        requested_for_label = f"({req_code}) - {req_name}" if req_name else req_code
        rep_code = t.reported_by
        rep_name = name_map.get(rep_code)
        requested_by_label = f"({rep_code}) - {rep_name}" if rep_name else rep_code
        tickets.append({
            'issue_id': t.issue_id,
            'ticket_id': t.ticket_id,
            'title': t.title or 'Untitled',
            'application': getattr(t.app_id, 'app_name', '-'),
            'priority': t.priority or '-',
            'status': t.status or '-',
            'created_at': t.created_at,
            'updated_at': t.updated_at,
            'service': getattr(t.service, 'name', '-'),
            'category': getattr(t.category, 'name', '-'),
            'sub_category': getattr(t.sub_category, 'name', '-'),
            'sub_sub_category': getattr(t.sub_sub_category, 'name', '-'),
            'description': t.description or 'No description provided.',
            'requested_for': requested_for_label,
            'requested_by': requested_by_label,
        })
    context = {"tickets": tickets, "page_title": "Resolved"}
    return render(request, "engineer_resolved_task.html", context)


@require_http_methods(["POST"])
def sm_assign_ticket(request):
    """Assign a ticket to an engineer, set status to In Progress, record assignment."""
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")
    if role not in ("SM1","SM2") or not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)

    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    issue_id = payload.get('issue_id')
    assigned_to = payload.get('assigned_to')
    override = payload.get('override') in (True, 'true', 'True', '1', 1)
    reason = payload.get('reason') or ''
    if not issue_id or not assigned_to:
        return JsonResponse({"ok": False, "error": "issue_id and assigned_to are required"}, status=400)

    from tickets.models import TicketMaster, TicketAssignment
    try:
        tm = TicketMaster.objects.get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    # Record assignment
    TicketAssignment.objects.create(
        issue_id=tm,
        assigned_by=emp_code,
        assigned_to=assigned_to,
        assigned_by_role=role,
    )

    # Update ticket status to In Progress
    tm.status = "In Progress"
    tm.save(update_fields=["status", "updated_at"])

    return JsonResponse({"ok": True})


@require_http_methods(["POST"])
def resolve_ticket(request):
    """Resolve a ticket from SM or Engineer with optional comment."""
    from django.http import JsonResponse
    role = request.session.get("role")
    emp_code = request.session.get("emp_code")
    if role not in ("SM1","SM2","Engineer") or not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    import json
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    issue_id = payload.get('issue_id')
    comment = (payload.get('comment') or '').strip()
    if not issue_id:
        return JsonResponse({"ok": False, "error": "issue_id is required"}, status=400)

    from tickets.models import TicketMaster, TicketComment
    try:
        tm = TicketMaster.objects.get(pk=issue_id)
    except TicketMaster.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket not found"}, status=404)

    if comment:
        TicketComment.objects.create(issue_id=tm, commented_by=emp_code, comment_text=comment)
    tm.status = "Resolved"
    tm.save(update_fields=["status", "updated_at"])
    return JsonResponse({"ok": True})


@require_http_methods(["GET"])
def logout_view(request):
    """Clear session and redirect to login page."""
    request.session.flush()
    return redirect("/auth/login/")

@require_http_methods(["GET"])
def employees_list(request):
    """Return active employees for Requested For dropdown."""
    q = request.GET.get("q", "").strip()
    sub_lob = request.session.get("sub_lob")
    # If sub_lob missing, try to fetch via HRMS using session email
    if not sub_lob and request.session.get("business_email"):
        hrms = get_employee_by_business_email(request.session.get("business_email"))
        if hrms and hrms.get("sub_lob"):
            sub_lob = hrms.get("sub_lob")
            request.session["sub_lob"] = sub_lob
    items = list_active_employees_by_sub_lob(sub_lob or "", q)
    from django.http import JsonResponse
    return JsonResponse({"results": items})


@require_http_methods(["GET"])
def engineers_list(request):
    """Return list of Engineers based on RoleMapping -> Role(name='Engineer')."""
    from django.http import JsonResponse
    try:
        role = Role.objects.get(name="Engineer")
    except Role.DoesNotExist:
        return JsonResponse({"results": []})

    mappings = RoleMapping.objects.filter(role=role).values_list("emp_code", flat=True)
    emps = HrmsEmployee.objects.filter(emp_code__in=list(mappings)).order_by("first_name", "last_name")
    results = [
        {
            "emp_code": e.emp_code,
            "label": f"{e.first_name} {e.last_name} ({e.emp_code})",
        }
        for e in emps
    ]
    return JsonResponse({"results": results})


@require_http_methods(["GET"])
def my_roles(request):
    from django.http import JsonResponse
    emp_code = request.session.get("emp_code")
    if not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    from .models import RoleMapping
    role_names = list(RoleMapping.objects.filter(emp_code=emp_code).select_related('role').values_list('role__name', flat=True))
    # Keep unique order
    seen = set()
    roles_unique = []
    for r in role_names:
        if r not in seen:
            roles_unique.append(r)
            seen.add(r)
    return JsonResponse({"ok": True, "roles": roles_unique, "active": request.session.get("role")})


@require_http_methods(["POST"])
def switch_role(request):
    from django.http import JsonResponse
    import json
    emp_code = request.session.get("emp_code")
    if not emp_code:
        return JsonResponse({"ok": False, "error": "Unauthorized"}, status=403)
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        payload = request.POST
    target = (payload.get('role') or '').strip()
    if not target:
        return JsonResponse({"ok": False, "error": "role is required"}, status=400)
    from .models import RoleMapping
    assigned = set(RoleMapping.objects.filter(emp_code=emp_code).select_related('role').values_list('role__name', flat=True))
    if target not in assigned:
        return JsonResponse({"ok": False, "error": "Role not assigned"}, status=403)
    request.session['role'] = target
    # Compute redirect for role
    redirect_map = {
        'User': '/auth/user/dashboard/',
        'SM1': '/auth/sm/dashboard/',
        'SM2': '/auth/sm/dashboard/',
        'Engineer': '/auth/eng/my-task/',
        'Admin': '/auth/admin/dashboard/',
    }
    return JsonResponse({"ok": True, "redirect": redirect_map.get(target, '/auth/login/')})
