from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('coreauth', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='rolemapping',
            name='emp_code',
            field=models.CharField(max_length=10),
        ),
    ]
